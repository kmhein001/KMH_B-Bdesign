<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?>  
    <!-- Link -->
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/blogs/blog-5/assets/css/blog-5.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/paginations/pagination-1/assets/css/pagination-1.css">
  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>

    <!-- Blog Section -->
    <section class="px-2 px-md-3 px-xl-5" style="background-color: rgb(255, 255, 255);">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="bsb-blog-5 p-2 p-md-3 p-xl-5" style="background-color: rgba(255, 255, 255, 0.781);">
                        <div class="container overflow-hidden">
                            <div class="row align-items-center gy-3 gy-md-0 gx-xl-5">

                                <?php
                                // Include the database connection
                                include('connection.php');

                                // Check if the connection was successful
                                if (!$conn) {
                                    die("Database connection failed: " . mysqli_connect_error());
                                }

                                // Pagination setup
                                $limit = 3; // Number of blog posts per page
                                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page
                                $offset = ($page - 1) * $limit; // Offset for SQL query

                                // Fetch total number of blog posts for pagination
                                $totalQuery = "SELECT COUNT(*) as total FROM bloglist";
                                $totalResult = mysqli_query($conn, $totalQuery);
                                $totalRow = mysqli_fetch_assoc($totalResult);
                                $totalPosts = $totalRow['total']; // Total number of blog posts
                                $totalPages = ceil($totalPosts / $limit); // Total pages

                                // Fetch blog posts from the database with LIMIT and OFFSET for pagination
                                $query = "SELECT `Name`, `Title`, `Date`, `Description`, `img`, `id` FROM bloglist ORDER BY `Date` DESC LIMIT $limit OFFSET $offset";
                                $result = mysqli_query($conn, $query);

                                // Check for errors in the query execution
                                if (!$result) {
                                    echo "<p>Error fetching blog posts: " . mysqli_error($con) . "</p>";
                                } else {
                                    // Check if there are blog posts
                                    if (mysqli_num_rows($result) > 0) {
                                        // Loop through the blog posts
                                        $index = 0; // Initialize index to track odd/even
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            $name = htmlspecialchars($row['Name']);
                                            $title = htmlspecialchars($row['Title']);
                                            $date = htmlspecialchars($row['Date']);
                                            $description = htmlspecialchars($row['Description']);
                                            $image = htmlspecialchars($row['img']);

                                            // Determine if the current index is odd or even for layout
                                            if ($index % 2 === 0) {
                                                // Even index - regular layout
                                                echo '<div class="col-12">';
                                                echo '<div class="bsb-blog-5 p-2 p-md-3 p-xl-5" style="background-color: rgba(255, 255, 255, 0.781);">';
                                                echo '<div class="container overflow-hidden">';
                                                echo '<div class="row align-items-center gy-3 gy-md-0 gx-xl-5">';
                                                echo '<div class="col-xs-12 col-md-6">';
                                                echo '<div class="img-wrapper position-relative bsb-hover-push">';
                                                echo '<a href="blog-detail.php?id=' . $row['id'] . '">';
                                                echo '<span class="badge rounded-pill text-bg-warning position-absolute top-0 start-0 m-3">' . $name . '</span>';
                                                echo '<img class="img-fluid rounded w-100 h-100 object-fit-cover" loading="lazy" src="admin/img/addblog/' . $image . '" alt="' . $name . '">';
                                                echo '</a>';
                                                echo '</div>';
                                                echo '</div>';
                                                echo '<div class="col-xs-12 col-md-6">';
                                                echo '<div>';
                                                echo '<p class="text-secondary mb-1">' . $date . '</p>';
                                                echo '<h2 class="h1 mb-3"><a class="link-dark text-decoration-none" href="blog-detail.php?id=' . $row['id'] . '">' . $title . '</a></h2>';
                                                echo '<p class="mb-4">' . $description . '</p>';
                                                echo '<a class="btn btn-button-click" href="Coming Soon.php?id=' . $row['id'] . '" target="_self">Read More</a>';
                                                echo '</div>';
                                                echo '</div>';
                                                echo '</div>'; // Close row
                                                echo '</div>'; // Close container
                                                echo '</div>'; // Close col-12
                                            } else {
                                                // Odd index - reversed layout
                                                echo '<div class="col-12">';
                                                echo '<div class="bsb-blog-5 p-2 p-md-3 p-xl-5" style="background-color: rgba(255, 255, 255, 0.781);">';
                                                echo '<div class="container overflow-hidden">';
                                                echo '<div class="row align-items-center flex-row-reverse gy-3 gy-md-0 gx-xl-5">';
                                                echo '<div class="col-xs-12 col-md-6">';
                                                echo '<div class="img-wrapper position-relative bsb-hover-push">';
                                                echo '<a href="blog-detail.php?id=' . $row['id'] . '">';
                                                echo '<span class="badge rounded-pill text-bg-warning position-absolute top-0 end-0 m-3">' . $name . '</span>';
                                                echo '<img class="img-fluid rounded w-100 h-100 object-fit-cover" loading="lazy" src="admin/img/addblog/' . $image . '" alt="' . $name . '">';
                                                echo '</a>';
                                                echo '</div>';
                                                echo '</div>';
                                                echo '<div class="col-xs-12 col-md-6">';
                                                echo '<div>';
                                                echo '<p class="text-secondary mb-1">' . $date . '</p>';
                                                echo '<h2 class="h1 mb-3"><a class="link-dark text-decoration-none" href="blog-detail.php?id=' . $row['id'] . '">' . $title . '</a></h2>';
                                                echo '<p class="mb-4">' . $description . '</p>';
                                                echo '<a class="btn btn-button-click" href="Coming Soon.php?id=' . $row['id'] . '" target="_self">Read More</a>';
                                                echo '</div>';
                                                echo '</div>';
                                                echo '</div>'; // Close row
                                                echo '</div>'; // Close container
                                                echo '</div>'; // Close col-12
                                            }

                                            // Increment index
                                            $index++;
                                        }
                                    } else {
                                        echo '<p>No blog posts found.</p>';
                                    }
                                }
                                ?>

                            </div>
                        </div>
                        <div class="col-12 mt-6">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination justify-content-center">

                                    <?php
                                    // Pagination links
                                    echo '<li class="page-item ' . ($page <= 1 ? 'disabled' : '') . '">';
                                    echo '<a class="page-link" href="?page=' . ($page - 1) . '" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a>';
                                    echo '</li>';

                                    // Page number links
                                    for ($i = 1; $i <= $totalPages; $i++) {
                                        echo '<li class="page-item ' . ($i == $page ? 'active' : '') . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
                                    }

                                    // Next page link
                                    echo '<li class="page-item ' . ($page >= $totalPages ? 'disabled' : '') . '">';
                                    echo '<a class="page-link" href="?page=' . ($page + 1) . '" aria-label="Next"><span aria-hidden="true">&raquo;</span></a>';
                                    echo '</li>';
                                    ?>

                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
  </body>
</html>
