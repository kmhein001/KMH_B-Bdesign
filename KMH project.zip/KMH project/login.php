<?php
// login.php

// Start the session to manage user sessions
session_start();

// Include the database connection
include_once('connection.php');

// Initialize variables to store form data and error messages
$username_or_email = $password = "";
$errors = [];

// Function to sanitize input data
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    // Sanitize and assign form inputs
    $username_or_email = sanitize_input($_POST["email"]); // 'email' field used for username or email
    $password = $_POST["password"];
    $remember_me = isset($_POST['remember_me']) ? $_POST['remember_me'] : '';

    // Validate inputs
    if (empty($username_or_email)) {
        $errors[] = "Email or Username is required.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    // If no validation errors, proceed to authenticate
    if (empty($errors)) {
        // Prepare the SQL statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE email = ? OR username = ?");

        if ($stmt) {
            // Bind parameters (s = string)
            $stmt->bind_param("ss", $username_or_email, $username_or_email);

            // Execute the statement
            $stmt->execute();

            // Store the result to free the connection for other queries
            $stmt->store_result();

            // Check if user exists
            if ($stmt->num_rows > 0) {
                // Bind result variables
                $stmt->bind_result($id, $username, $hashed_password);

                // Fetch the result
                $stmt->fetch();

                // Verify the password
                if (password_verify($password, $hashed_password)) {
                    // Password is correct, set session variables
                    $_SESSION['user_id'] = $id;
                    $_SESSION['username'] = $username;

                    // Optional: Implement "Remember Me" functionality
                    if ($remember_me) {
                        // Generate a random token
                        $token = bin2hex(random_bytes(16));

                        // Set a secure, HTTP-only cookie that expires in 30 days
                        setcookie("remember_me", $token, time() + (86400 * 30), "/", "", isset($_SERVER['HTTPS']), true);

                        // Store the token in the database
                        $update_stmt = $conn->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                        if ($update_stmt) {
                            $update_stmt->bind_param("si", $token, $id);
                            $update_stmt->execute();
                            $update_stmt->close();
                        } else {
                            // Handle preparation error for UPDATE statement
                            error_log("Update Statement Preparation Failed: " . $conn->error);
                            // Optionally, add an error message or handle as needed
                        }
                    }

                    // Regenerate session ID to prevent session fixation
                    session_regenerate_id(true);

                    // Close the first statement
                    $stmt->close();

                    // Redirect to the test page
                    header("Location: test.php");
                    exit();

                } else {
                    // Incorrect password
                    $errors[] = "Invalid email/username or password.";
                }
            } else {
                // No user found with the provided email or username
                $errors[] = "Invalid email/username or password.";
            }

            // Close the statement
            $stmt->close();
        } else {
            // SQL statement preparation failed
            $errors[] = "An error occurred. Please try again later.";
            // Log the detailed error message for debugging
            error_log("Login SQL Error: " . $conn->error);
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
      <!-- Head -->
        <?php include_once('connect resource php/head.php'); ?>  
      <!-- Link -->
      <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/registrations/registration-9/assets/css/registration-9.css">
  </head>
  <body>
      <!-- Header Navbar -->
      <?php include_once('connect resource php/Header Navbar.php'); ?>
      <!-- Login -->
      <section class="py-2 py-md-3 py-xl-5" style="background-color: white;">
        <div class="container-fluid">
          <div class="row"> 
            <div class="col-12">
              <div class="container py-2 py-md-3 py-xl-5 px-2 px-md-3 px-md-5" style="background-color: rgba(230, 230, 230, 0.835); border-radius:30px;">
                <div class="row gy-4 align-items-center">
                  <div class="col-12 col-md-6 col-xl-7">
                    <div class="d-flex justify-content-center" style="background-color: #105470;border-radius:30px;">
                      <div class="col-12 col-xl-11 text-white">
                        <img class="img-fluid rounded my-4" style="border-radius:30px;" loading="lazy" src="img/Login.gif" alt="BootstrapBrain Logo">
                        <hr class="border-white my-2 border-4">
                        <h2 class="h1 my-2 ms-3">B&B Design Build Construction - Innovate, Design, Build</h2>
                        <p class="lead my-2 ms-3">"At B&B Design Build, we transform your vision into reality with our expert construction services, combining innovative......</p>
                        <div class="text-end me-3">
                          <i class="bi bi-grip-horizontal" style="font-size: 48px; color: currentColor;"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Display Error Messages -->
                  <?php
                    if (!empty($errors)) {
                        echo '<div class="alert alert-danger"><ul>';
                        foreach ($errors as $error) {
                            echo '<li>' . htmlspecialchars($error) . '</li>';
                        }
                        echo '</ul></div>';
                    }

                    // Display success message if redirected from registration
                    if (isset($_SESSION['success'])) {
                        echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
                        unset($_SESSION['success']);
                    }
                    ?>        
                  <div class="col-12 col-md-6 col-xl-5">
                    <div class="card border-0 rounded-4">
                      <div class="card-body p-3 p-md-4 p-xl-5">
                        <div class="row">
                          <div class="col-12">
                            <div class="mb-4">
                              <h3 class="d-flex flex-column flex-md-row justify-content-center fs-1 pb-5"><b>Sign in</b></h3>
                              <p class="d-flex flex-column flex-md-row justify-content-center pb-5 fs-5">Don't have an account? <a href="registration.php">&nbsp;<b>Sign up</b></a></p>
                            </div>
                          </div>
                        </div>
                        
                        <form method="post" action="">
                          <!-- (Optional) Include CSRF Token here if implemented -->
                          <!-- <input type="hidden" name="csrf_token" value="<?php // echo $_SESSION['csrf_token']; ?>"> -->
                          <div class="row gy-3 overflow-hidden">
                            <div class="col-12">
                              <div class="form-floating mb-3">
                                  <input type="text" class="form-control" name="email" id="email" placeholder="Username or Email" value="<?php echo htmlspecialchars($username_or_email); ?>" required>
                                  <label for="email" class="form-label"><b>Username or Email</b></label>
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="form-floating mb-3">
                                  <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                  <label for="password" class="form-label"><b>Password</b></label>
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="form-check">
                                  <input class="form-check-input" type="checkbox" name="remember_me" id="remember_me">
                                  <label class="form-check-label text-secondary" for="remember_me">
                                      Keep me logged in
                                  </label>
                              </div>
                            </div>
                            <div class="col-12">
                              <div class="d-grid">
                                  <button class="btn btn-brand btn-lg" type="submit" name="login">Log in now</button>
                              </div>
                            </div>
                          </div>
                        </form>
                        <div class="row">
                          <div class="col-12">
                              <div class="d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-end mt-4">
                                  <a href="password_reset.php"><b>Forgot password</b></a> <!-- Fixed the filename -->
                              </div>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-12">
                              <p class="my-5 d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-center">Or continue with</p> <!-- Removed stray </span> -->
                            <div class="d-flex gap-2 gap-sm-3 justify-content-center">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-danger bsb-btn-circle bsb-btn-circle-2xl">
                                    <i class="bi bi-google" style="font-size: 24px; color: currentColor;"></i>
                                </a>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-primary bsb-btn-circle bsb-btn-circle-2xl">
                                    <i class="bi bi-facebook" style="font-size: 24px; color: currentColor;"></i>
                                </a>
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-dark bsb-btn-circle bsb-btn-circle-2xl">
                                    <i class="bi bi-apple" style="font-size: 24px; color: currentColor;"></i>
                                </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        <!-- Footer -->
        <?php include_once('connect resource php/Footer.php'); ?> 

        <!-- Modal for Coming Soon Features (Optional) -->
        <div class="modal fade" id="comingSoonModal" tabindex="-1" aria-labelledby="comingSoonModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Coming Soon</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        This feature is coming soon. Stay tuned!
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
