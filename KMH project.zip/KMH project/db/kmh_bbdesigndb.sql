-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2024 at 04:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kmh_bbdesigndb`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloglist`
--

CREATE TABLE `bloglist` (
  `ID` int(100) NOT NULL,
  `Name` varchar(300) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Date` date DEFAULT NULL,
  `Description` varchar(500) NOT NULL,
  `img` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bloglist`
--

INSERT INTO `bloglist` (`ID`, `Name`, `Title`, `Date`, `Description`, `img`) VALUES
(1, 'House Design', 'Top House Design Trends of 2024', '2022-11-11', 'Explore the latest trends in house design that are shaping the architectural landscape in 2024. From sustainable materials to innovative layouts, get inspired for your next home project.', 'House-Design-1.jpg'),
(2, 'Brick Design', 'Innovative Brick Designs for Modern Homes', '2022-10-10', 'rickwork isn\\\\\\\'t just for traditional builds anymore. Discover the innovative brick designs that are being used to create modern, stylish, and sustainable homes.', 'Brick Design-1.jpg'),
(3, 'Building Projects', 'Planning Your Next Building Project: A Comprehensive Guide', '2022-09-17', 'From budgeting to design to construction, this comprehensive guide walks you through the steps of planning your next building project with confidence.', 'Building Projects-1.jpg'),
(4, 'Concrete Brick Design', 'Creative Uses for Concrete Blocks in Modern Construction', '2022-08-23', 'Concrete blocks are a staple of modern construction. Learn how architects and builders are using these versatile materials in creative and sustainable ways.', 'Concrete Block Design-1.jpg'),
(5, 'Home Renovations', 'Maximizing Your Space with Innovative Brick and Concrete Renovations', '2022-07-13', 'Home renovations using innovative brick and concrete solutions can significantly enhance space efficiency. Explore ideas that add value and style to your living environment.', 'Home Renovations-1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `ID` int(40) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(300) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Subject` varchar(255) NOT NULL,
  `Message` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`ID`, `Name`, `Email`, `Phone`, `Subject`, `Message`) VALUES
(1, 'Ma Sew Oo', 'sewoo01@gmail.com', '0987314190', 'House Design Project', 'I’m looking to build a modern, two-story house with a minimalist design. I want large windows for natural light and an open floor plan with three bedrooms, two bathrooms, and a spacious kitchen. Sustainability is important to me, so I’d like to explore eco-friendly materials and energy-efficient options. I’m hoping to begin construction in six months and would appreciate advice on budgeting and timelines. Looking forward to your design ideas!'),
(2, 'Moe Moe Kyaw', 'moemoekyaw01@gmail.com', '0913456723', 'Modern Kitchen Remodel', 'I’m planning to remodel my kitchen and am looking for a sleek, modern design. I want a large kitchen island with plenty of seating and counter space, as well as smart storage solutions for a more organized space. I’m thinking about adding stainless steel appliances and modern lighting fixtures. Could you suggest design options that would enhance both functionality and aesthetics? I’d also appreciate help with budgeting and material selection.'),
(3, 'Kyaw Min Htun', 'kyawminhtun01@gmail.com', '0921876543', 'Small Office Design', 'I’ve recently leased a small office and need help designing a functional workspace. The area is just 400 square feet, so space efficiency is key. I’d like to include a small reception area, two workstations, and a conference room. I’m interested in a minimalist design with clean lines and neutral colors. Can you provide layout suggestions and ideas on how to maximize the space without making it feel cramped?'),
(4, 'Hlaing Hlaing Aye', 'hlainghlaingaye01@gmail.com', '0984312576', 'Home Exterior Redesign', 'I’m looking to update the exterior of my home to give it a more modern look. I’m thinking of replacing the current siding with a combination of wood and stone, as well as updating the front porch. I’d also like to improve the landscaping to create more curb appeal. Could you assist with design ideas for the exterior, including color schemes and materials that would work well in our climate?'),
(5, 'Thant Zin Lwin', 'thantzinlwin01@gmail.com', '0976210345', 'Retail Store Expansion', 'I’m expanding my retail store and need help designing the new layout. The additional space will allow for more product displays, but I want to make sure the store feels cohesive. I’m particularly interested in how to organize the flow of customers and optimize the use of display racks. Could you help with layout suggestions and provide guidance on lighting options that would highlight the products effectively?'),
(6, 'Khine Khine Win', 'khinekhinewin01@gmail.com', '0945382176', 'Custom Home Design', 'I’m looking to design a custom home that reflects my family’s lifestyle. We need four bedrooms, three bathrooms, and a large living area that’s great for entertaining. We’re interested in a modern design with open spaces, but also want a cozy family room. Outdoor living is important to us, so we’d love a large deck and a small garden area. Could you provide design options and a cost estimate for a project like this?');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `session_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `session_id`, `name`, `phone`, `address`, `total_price`, `created_at`) VALUES
(1, 'gqns5dulunp1vra5obacub99j2', 'Ma Sew Oo', '0987314190', 'North Dagon, Yangon', 2120000.00, '2024-10-05 17:47:04'),
(3, 'tpkdjjals7q0vlnlt02mjos90t', 'Moe Moe Kyaw', '0913456723', 'Mandalay', 820000.00, '2024-10-06 01:49:52'),
(4, 'tpkdjjals7q0vlnlt02mjos90t', 'Kyaw Min Htun', '0921876543', 'Yangon', 740000.00, '2024-10-06 01:50:27');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 1, 1, 150000.00),
(2, 1, 2, 1, 120000.00),
(3, 1, 4, 1, 800000.00),
(4, 1, 5, 1, 80000.00),
(5, 1, 6, 1, 200000.00),
(6, 1, 7, 1, 210000.00),
(7, 1, 8, 1, 560000.00),
(10, 3, 2, 1, 120000.00),
(11, 3, 3, 2, 350000.00),
(12, 4, 1, 1, 150000.00),
(13, 4, 2, 2, 120000.00),
(14, 4, 3, 1, 350000.00);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`id`, `email`, `token`, `created_at`, `expires_at`) VALUES
(1, 'sewoo01@gmail.com', 'b29ce2c5f8c03785b3cf32c491900275', '2024-10-05 13:30:22', '2024-10-05 10:00:22'),
(2, 'moemoekyaw01@gmail.com', 'e0ba3b651e04e8f94085dbbc63aae23b', '2024-10-06 01:59:07', '2024-10-06 02:59:07'),
(3, 'kyawminhtun01@gmail.com', 'ec3c91d91f81cc045ba20de81d566259', '2024-10-06 01:59:43', '2024-10-06 02:59:43'),
(4, 'hlainghlaingaye01@gmail.com', '04220732291b304cb30e0fc4658b9414', '2024-10-06 01:59:52', '2024-10-06 02:59:52'),
(5, 'thantzinlwin01@gmail.com', '5c23777b7ad560d8722e649d0a5413d4', '2024-10-06 02:00:00', '2024-10-06 03:00:00'),
(6, 'khinekhinewin01@gmail.com', '45ae0a7e032a0996a79a91e5bf377bb5', '2024-10-06 02:00:09', '2024-10-06 03:00:09');

-- --------------------------------------------------------

--
-- Table structure for table `productlist`
--

CREATE TABLE `productlist` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) NOT NULL,
  `Subtitle` varchar(255) NOT NULL,
  `Price` int(20) NOT NULL,
  `Discount` int(20) NOT NULL,
  `Description` varchar(500) NOT NULL,
  `Shipping` varchar(255) NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `productlist`
--

INSERT INTO `productlist` (`ID`, `Name`, `Subtitle`, `Price`, `Discount`, `Description`, `Shipping`, `img`) VALUES
(1, ' RG+ Polymeric Sand Sable Polymere', '50 lb', 150000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Paid Shipping', 'P-1.png'),
(2, 'Techniseal HP NextGel Polymeric Sand', '50 lb.Bag', 120000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Free Shipping', 'P-2.png'),
(3, 'Gator Maxx Polymeric Sand', '50lb', 350000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Free Shipping', 'P-3.png'),
(4, 'Sleeve-It Fence Post System', '12″ Diameter', 800000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Free Shipping', 'P-4.png'),
(5, ' Snap Edge Paver Restraint', '8 ft. length', 80000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Free Shipping', 'P-5.png'),
(6, 'NMD80 Masonry Detergent', '1 Gallon', 200000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Paid Shipping', 'P-6.png'),
(7, 'EF-Fortless Efflorescence Cleaners', '1 Gallon', 210000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!', 'Free Shipping', 'P-7.png'),
(8, 'One Restore Restoration Detergent', '1 Gallon', 560000, 0, 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Facilis possimus ut quia saepe omnis accusantium? Voluptatem quia eum commodi odit. Voluptatibus omnis mollitia inventore beatae accusamus quaerat? Pariatur, nihil tenetur!\r\n', 'Free Shipping', 'P-8.png');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `ID` int(11) NOT NULL,
  `Session_ID` varchar(255) NOT NULL,
  `Product_ID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Added_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `remember_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstName`, `lastName`, `username`, `email`, `password`, `created_at`, `remember_token`) VALUES
(1, 'Ma Sew', 'Oo', 'sewoo01', 'sewoo01@gmail.com', '$2y$10$eqPchiLsKArI0tp8RGPa8ettiFl8vbGnk/4nNYV6Fgg1SmbiwaGCO', '2024-10-05 12:36:28', '2a5eb40bc299efd0aecf0767ee8c857f'),
(2, 'Moe Moe', 'Kyaw', 'moemoekyaw01', 'moemoekyaw01@gmail.com', '$2y$10$mg.k021Xcx58tQAzpmQog.gy.cotU5WD6nk2VJedMJ8eh4cokXExe', '2024-10-06 01:42:15', NULL),
(3, 'Kyaw Min', 'Htun', 'kyawminhtun01', 'kyawminhtun01@gmail.com', '$2y$10$Es4JqMgF07EK4CrcedZ9Ful2SExrUvHZHPnQzWquwIbMr20A5dzNa', '2024-10-06 01:43:34', NULL),
(4, 'Hlaing Hlaing', 'Aye', 'hlainghlaingaye01', 'hlainghlaingaye01@gmail.com', '$2y$10$pEy57bSf1G8a7X4YHF4r4exisvDqF0d/FfQ/n95hhGo9C0GVdyrhq', '2024-10-06 01:44:34', NULL),
(5, 'Thant Zin', 'Lwin', 'thantzinlwin01', 'thantzinlwin01@gmail.com', '$2y$10$V.tUQvybQ11AO80TsPS/CefCmotK3Ar8TmqwV56hXsM3WzqoR05wu', '2024-10-06 01:45:38', NULL),
(6, 'Khine Khine', 'Win', 'khinekhinewin01', 'khinekhinewin01@gmail.com', '$2y$10$MSK9et24WZfZFQZtgRTqOOWLbfi43DFIymXxezsYdz8TnaKWw./VO', '2024-10-06 01:46:39', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloglist`
--
ALTER TABLE `bloglist`
  ADD PRIMARY KEY (`ID`) USING BTREE;

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `productlist`
--
ALTER TABLE `productlist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloglist`
--
ALTER TABLE `bloglist`
  MODIFY `ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `ID` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `productlist`
--
ALTER TABLE `productlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `productlist` (`ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
