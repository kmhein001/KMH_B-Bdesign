<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?> 
</head>
    <body>
        <!-- Header Navbar -->
        <?php include_once('connect resource php/Header Navbar.php'); ?>
        <main>
            <!-- Slider -->
            <section>
                <div class="row">
                    <div class="col-xl-12">
                        <div id="carouselExampleCaptions" class="carousel slide">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="img/Carouser/H-1.jpg" class="d-block w-100 h-100" alt="Slide 1">
                                    <div class="carousel-caption d-md-block">
                                    <h5 class="tracking-in-expand-fwd fs-1" style="text-shadow:6px 3px 3px rgb(53, 3, 145);">Masterpieces in Brick and Block</h5>
                                    <p class="fs-3" style="text-shadow:6px 4px 4px rgb(145, 65, 3);">Explore the timeless beauty and strength of our brick and block designs, perfect for creating structures that stand the test of time.</p>
                                    <a href="Coming Soon.php" class="btn btn-brand me-5">Learn</a>
                                    <a href="Coming Soon.php" class="btn btn-brand ms-5">Buy Now</a>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img src="img/Carouser/H-3.jpg" class="d-block w-100 h-100" alt="Slide 2">
                                    <div class="carousel-caption d-md-block">
                                    <h5 class="tracking-in-expand-fwd fs-1" style="text-shadow:6px 3px 3px rgb(53, 3, 145);">Build with Confidence</h5>
                                    <p class="fs-3" style="text-shadow:6px 4px 4px rgb(145, 65, 3);">Our bricks and blocks are crafted for durability and precision, ensuring your projects are built on a foundation of excellence.</p>
                                    <a href="Coming Soon.php" class="btn btn-brand me-5">Learn</a>
                                    <a href="Coming Soon.php" class="btn btn-brand ms-5">Buy Now</a>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img src="img/Carouser/H-2.jpg" class="d-block w-100 h-100" alt="Slide 3">
                                    <div class="carousel-caption d-md-block">
                                    <h5 class="tracking-in-expand-fwd fs-1" style="text-shadow:6px 3px 3px rgb(53, 3, 145);">Enduring Elegance</h5>
                                    <p class="fs-3" style="text-shadow:6px 4px 4px rgb(145, 65, 3);">Brick and block construction redefined. Achieve the perfect balance of style and sturdiness in every build with our top-quality materials.</p>
                                    <a href="Coming Soon.php" class="btn btn-brand me-5">Learn</a>
                                    <a href="Coming Soon.php" class="btn btn-brand ms-5">Buy Now</a>
                                    </div>
                                </div>
                            </div>
                            <button class="carousel-control-prev" style="left:10%;" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" style="right:10%;" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>
            <!-- content -->
            <section class="p-4 p-md-3 p-xl-4" style="background-color: rgb(255, 255, 255);">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="container">
                                <div class="py-5">
                                    <h1 class="text-center text-3xl fw-bold mb-4">Build better with B&B DesginBuild</h1>
                                    <p class="text-center">
                                        Our vast selection of concrete masonry blocks, pavers and retaining wall products provide quality, strength, and style for any residential or commercial building project
                                    </p>
                                    <div class="row py-5">
                                        <div class="col-6">
                                            <div class="card text-white">
                                                <img src="img/home/H-1.jpg" class="card-img" alt="Concrete Masonry Units">
                                                <div class="card-img-overlay d-flex flex-column align-items-center justify-content-center text-overlay">
                                                    <h2 class="card-title tracking-in-contract text-white fw-semibold mb-3">Concrete Masonry Units</h2>
                                                    <p class="text-center text-white">Create a beautiful and long-lasting structure of any size with our brick.</p>
                                                    <a href="Coming Soon.php" class="btn btn-view-more rounded-lg px-4 py-2">Learn More!</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="card text-white">
                                                <img src="img/home/H-2.jpg" class="card-img" alt="Stone Veneers">
                                                <div class="card-img-overlay d-flex flex-column align-items-center justify-content-center text-overlay">
                                                    <h2 class="card-title tracking-in-contract text-white fw-semibold mb-3">Brick</h2>
                                                    <p class="text-center text-white">Create a beautiful and long-lasting structure of any size with our brick.</p>
                                                    <a href="Coming Soon.php" class="btn btn-view-more rounded-lg px-4 py-2">Learn More!</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 mt-4">
                                            <div class="card text-white">
                                                <img src="img/home/H-3.jpg" class="card-img" alt="Concrete Masonry Units">
                                                <div class="card-img-overlay d-flex flex-column align-items-center justify-content-center text-overlay">
                                                    <h2 class="card-title tracking-in-contract text-white fw-semibold mb-3">Hardscapes</h2>
                                                    <p class="text-center text-white">Reimagine the outdoor space for your home or business.</p>
                                                    <a href="Coming Soon.php" class="btn btn-view-more rounded-lg px-4 py-2">Learn More!</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 mt-4">
                                            <div class="card text-white">
                                                <img src="img/home/H-4.jpg" class="card-img" alt="Stone Veneers">
                                                <div class="card-img-overlay d-flex flex-column align-items-center justify-content-center text-overlay">
                                                    <h2 class="card-title tracking-in-contract text-white fw-semibold mb-3">Stone Veneers</h2>
                                                    <p class="text-center text-white">Craft a unique look both indoors and outdoors with these thinly cut stones.</p>
                                                    <a href="Coming Soon.php" class="btn btn-view-more rounded-lg px-4 py-2">Learn More!</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div> 
                                </div>
                            </div>
                            <div class="container py-5">
                                <div class="row justify-content-md-center">
                                <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                                    <h3 class="fs-5 mb-2 text-black text-center text-uppercase py-4">Our Achievements</h3>
                                        <h2 class="display-5 mb-5 mb-xl-9 text-center">Building a Legacy with Brick and Block Excellence.</h2>
                                    <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
                                </div>
                                </div>
                            </div>
                            <div class="container py-5">
                                <div class="row gy-4 gy-lg-0 align-items-lg-center">
                                    <div class="col-12 col-lg-6">
                                        <img class="img-fluid rounded" loading="lazy" src="img/Achievement-1.gif" alt="Our Success">
                                    </div>
                                    <div class="col-12 col-lg-6">
                                        <div class="row justify-content-xl-end">
                                            <div class="col-12 col-xl-11">
                                                <div class="row gy-4 gy-sm-0 overflow-hidden">
                                                    <div class="col-12 col-sm-6">
                                                        <div class="card border-0 border-bottom border-primary shadow-sm mb-4">
                                                            <div class="card-body text-center p-4 p-xxl-5">
                                                                <h3 class="display-4 fw-bold mb-2">60+</h3>
                                                                <p class="fs-5 mb-0 text-secondary">Completed B&B Projects</p>
                                                            </div>
                                                        </div>
                                                        <div class="card border-0 border-bottom border-primary shadow-sm">
                                                            <div class="card-body text-center p-4 p-xxl-5">
                                                                <h3 class="display-4 fw-bold mb-2">18k+</h3>
                                                                <p class="fs-5 mb-0 text-secondary">Challenges Mastered</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-12 col-sm-6">
                                                        <div class="card border-0 border-bottom border-primary shadow-sm mt-lg-6 mt-xxl-8 mb-4">
                                                            <div class="card-body text-center p-4 p-xxl-5">
                                                                <h3 class="display-4 fw-bold mb-2">10k+</h3>
                                                                <p class="fs-5 mb-0 text-secondary">Satisfied <br> Clients</p>
                                                            </div>
                                                        </div>
                                                        <div class="card border-0 border-bottom border-primary shadow-sm">
                                                            <div class="card-body text-center p-4 p-xxl-5">
                                                                <h3 class="display-4 fw-bold mb-2">78</h3>
                                                                <p class="fs-5 mb-0 text-secondary">Industry Awards</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <!-- Footer -->
        <?php include_once('connect resource php/Footer.php'); ?> 
    </body>
</html>