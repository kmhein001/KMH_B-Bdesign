<!DOCTYPE html>
<html lang="en">
  <head>
      <!-- Head -->
      <?php include_once('connect resource php/head.php'); ?>  
      <!-- Link -->
      <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/bsb-overlay/bsb-overlay.css">
      <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/background/background.css">
      <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/margin/margin.css">
      <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/padding/padding.css">

  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    <!-- Contact -->
    <section class="px-2 px-md-3 px-xl-5" style="background-color: rgb(255, 255, 255);">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="p-2 p-md-3 p-xl-5" style="background-color: rgba(255, 255, 255, 0.781);">
              <div class="container overflow-hidden">
                <div class="row justify-content-md-center">
                  <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                    <h2 class="mb-4 display-5 text-center">Need Us? Let's Talk!</h2>
                    <p class="text-secondary mb-5 text-center lead fs-4"><i>"Whether you're planning a big project or just need some advice, Brick & Block Design Build is here for you. Contact us today, and let's start a conversation."</i></p>
                    <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
                  </div>
                </div>
                <div class="container">
                  <div class="row">
                    <div class="col-12">
                      <div class="card border border-dark rounded shadow-sm overflow-hidden" >
                        <div class="card-body p-0">
                          <div class="row gy-3 gy-md-4 gy-lg-0">
                            <div class="col-12 col-lg-6 bsb-overlay background-position-center background-size-cover" style="--bsb-overlay-opacity: 0.4; background-color: #105470;">
                              <div class="row align-items-lg-center justify-content-center h-100">
                                <div class="col-11 col-xl-10">
                                  <div class="contact-info-wrapper py-4 py-xl-5">
                                    <?php  error_reporting(1);
                                        error_reporting(1);
                                        include('connection.php');

                                        if (isset($_POST['sub'])) {
                                          $name = $_POST['fullname'];
                                          $email = $_POST['email'];
                                          $phone = $_POST['phone'];
                                          $subject = $_POST['subject'];
                                          $message = $_POST['message'];
                                          
                                          // Using prepared statements
                                          $stmt = $conn->prepare("INSERT INTO `contact` (Name, Email, Phone, Subject, Message) VALUES (?, ?, ?, ?, ?)");
                                          $stmt->bind_param("sssss", $name, $email, $phone, $subject, $message);
                                          
                                          if ($stmt->execute()) {
                                              echo "<p style='color:green'>Message Sent Successfully!</p>";
                                          } else {
                                              echo "<p style='color:red'>Error: " . $stmt->error . "</p>";
                                          }
                                          
                                          $stmt->close();
                                      }
                                      
                                    ?>
                                    <h2 class="h1 mb-3 text-light">Contact Us!</h2>
                                    <p class="lead fs-4 text-light opacity-75 mb-2 mb-xxl-3">"Looking to start a new project or have any queries? Our team is just a message away. Contact us today, and let's discuss how we can transform your ideas into reality."</p>
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d3817.7280509721877!2d96.23404057588911!3d16.88934208143231!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zMTbCsDUzJzIxLjYiTiA5NsKwMTQnMTkuMiJF!5e0!3m2!1sen!2smm!4v1724504216977!5m2!1sen!2smm" width="100%" height="300" style="border:0; border-radius:20px" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                                    <div class="d-flex mt-2 mt-xxl-3 mb-4 mb-xxl-5">
                                      <div class="me-4 text-primary">
                                        <i class="bi bi-geo" style="font-size: 32px; color: currentColor;"></i>
                                      </div>
                                      <div>
                                        <h4 class="mb-3 text-light">Address</h4>
                                        <address class="mb-0 text-light opacity-75">No.2 High ways road, East Dagon Myothit Township, Yangon</address>
                                      </div>
                                    </div>
                                    <div class="row mb-4 mb-xxl-5">
                                      <div class="col-12 col-xxl-6">
                                        <div class="d-flex mb-4 mb-xxl-0">
                                          <div class="me-4 text-primary">
                                            <i class="bi bi-telephone-outbound" style="font-size: 32px; color: currentColor;"></i>
                                          </div>
                                          <div>
                                            <h4 class="mb-3 text-light">Phone</h4>
                                            <p class="mb-0">
                                              <a class="link-light link-opacity-75 link-opacity-100-hover text-decoration-none" href="tel:+95 9791045678">+95 9791045678</a>
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-12 col-xxl-6">
                                        <div class="d-flex mb-0">
                                          <div class="me-4 text-primary">
                                            <i class="bi bi-envelope-at" style="font-size: 32px; color: currentColor;"></i>
                                          </div>
                                          <div>
                                            <h4 class="mb-3 text-light">E-Mail</h4>
                                            <p class="mb-0">
                                              <a class="link-light link-opacity-75 link-opacity-100-hover text-decoration-none" href="mailto:contact@yourcompanyname.com.mm">contact@B&BDesignBuild.com.mm</a>
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="d-flex">
                                      <div class="me-4 text-primary">
                                        <i class="bi bi-alarm" style="font-size: 32px; color: currentColor;"></i>
                                      </div>
                                      <div>
                                        <h4 class="mb-3 text-light">Opening Hours</h4>
                                        <div class="d-flex mb-2">
                                          <p class="text-light fw-bold mb-0 me-2">Weekday:</p>
                                          <p class="text-light fw-bold mb-0 me-3">Mon - Fri</p>
                                          <p class="text-light opacity-75 mb-0">10am - 5pm</p>
                                        </div>
                                        <div class="d-flex">
                                          <p class="text-light fw-bold mb-0 me-2">Weekend:</p>
                                          <p class="text-light fw-bold mb-0 me-3">Sat - Sun</p>
                                          <p class="text-light opacity-75 mb-0">10am - 2pm</p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="col-12 col-lg-6">
                              <div class="row align-items-lg-center h-100">
                                <div class="col-12">
                                  <form action="contact.php" method="POST">
                                    <div class="row gy-4 gy-xl-5 p-4 p-xl-5">
                                        <div class="col-12">
                                            <div class="mb-2">
                                                <h3 class="d-flex flex-column flex-md-row justify-content-center fs-1 pb-2"><b>Contact us!</b></h3>
                                                <p class="d-flex flex-column flex-md-row justify-content-center pb-2 fs-5">"Have questions or need assistance with your next project? We’re here to help! Fill out the form below, and one of our team members at Brick & Block Design Build will get back to you as soon as possible."</p>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <label for="fullname" class="form-label">Full Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="fullname" name="fullname" required>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <span class="input-group-text">
                                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope" viewBox="0 0 16 16">
                                                    <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4Zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2Zm13 2.383-4.708 2.825L15 11.105V5.383Zm-.034 6.876-5.64-3.471L8 9.583l-1.326-.795-5.64 3.47A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.741ZM1 11.105l4.708-2.897L1 5.383v5.722Z" />
                                                  </svg>
                                                </span>
                                                <input type="email" class="form-control" id="email" name="email" required>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-6">
                                            <label for="phone" class="form-label">Phone Number</label>
                                            <div class="input-group">
                                                <span class="input-group-text">
                                                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone" viewBox="0 0 16 16">
                                                    <path d="M3.654 1.328a.678.678 0 0 0-1.015-.063L1.605 2.3c-.483.484-.661 1.169-.45 1.77a17.568 17.568 0 0 0 4.168 6.608 17.569 17.569 0 0 0 6.608 4.168c.601.211 1.286.033 1.77-.45l1.034-1.034a.678.678 0 0 0-.063-1.015l-2.307-1.794a.678.678 0 0 0-.58-.122l-2.19.547a1.745 1.745 0 0 1-1.657-.459L5.482 8.062a1.745 1.745 0 0 1-.46-1.657l.548-2.19a.678.678 0 0 0-.122-.58L3.654 1.328zM1.884.511a1.745 1.745 0 0 1 2.612.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z" />
                                                  </svg>
                                                </span>
                                                <input type="tel" class="form-control" id="phone" name="phone">
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <label for="subject" class="form-label">Subject <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="subject" name="subject" required>
                                        </div>
                                        <div class="col-12">
                                            <label for="message" class="form-label">Message <span class="text-danger">*</span></label>
                                            <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-grid">
                                                <button class="btn btn-brand btn-lg" type="submit" name="sub">Send Message</button>
                                            </div>
                                        </div>
                                    </div>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
  </body>
</html>