<?php
session_start();
include('connection.php');

// Get the current session ID
$session_id = session_id();

// Handle removal of items
if (isset($_GET['remove_id'])) {
    $remove_id = intval($_GET['remove_id']);
    $deleteQuery = "DELETE FROM shopping_cart WHERE id = '$remove_id' AND session_id = '$session_id'";
    mysqli_query($conn, $deleteQuery);
    header('Location: shopping_cart.php'); // Redirect to the same page
    exit();
}

// Handle quantity updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    foreach ($_POST['quantities'] as $cart_id => $quantity) {
        $cart_id = intval($cart_id);
        $quantity = intval($quantity);
        if ($quantity > 0) {
            $updateQuery = "UPDATE shopping_cart SET quantity = '$quantity' WHERE id = '$cart_id' AND session_id = '$session_id'";
            mysqli_query($conn, $updateQuery);
        }
    }
    header('Location: shopping_cart.php'); // Redirect to the same page
    exit();
}

// Fetch cart items
$cartQuery = "SELECT sc.id as cart_id, p.id as product_id, p.name, p.subtitle, p.price, p.discount, p.img, sc.quantity
             FROM shopping_cart sc
             JOIN productlist p ON sc.product_id = p.id
             WHERE sc.session_id = '$session_id'";
$cartResult = mysqli_query($conn, $cartQuery);

// Calculate total price
$totalPrice = 0;
$totalItems = 0; // Count the total number of items
$cartItems = []; // Initialize an array to store cart items

while ($item = mysqli_fetch_assoc($cartResult)) {
    $totalPrice += $item['price'] * $item['quantity'];
    $totalItems += $item['quantity']; // Update total items count
    $cartItems[] = $item; // Store item for later use in display
}

// Define discount based on the number of items
if ($totalItems >= 10) {
    $discountRate = 0.08; // 8% discount for 10 items or more
} elseif ($totalItems >= 5) {
    $discountRate = 0.05; // 5% discount for 5 items or more
} else {
    $discountRate = 0.00; // No discount for less than 5 items
}

$discountAmount = $totalPrice * $discountRate; // Calculate discount amount
$taxRate = 0.008; // 0.8% tax rate
$taxAmount = $totalPrice * $taxRate; // Calculate tax amount

// Calculate final total after discount and tax
$finalTotal = $totalPrice - $discountAmount + $taxAmount;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Your Shopping Cart</title>
    <?php include_once('connect resource php/head.php'); ?>
    <script>
        // Automatically submit the form when quantity changes
        function updateCart(form) {
            form.submit();
        }
    </script>
</head>
<body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    
    <section class="p-2 p-md-3 p-xl-5" style="background-color: rgb(255, 255, 255);">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">      
            <!-- cart + summary -->
            <section class="bg-light">
              <div class="container">
                <div class="row">
                  <!-- cart -->
                  <div class="col-lg-9 py-4">
                    <div class="card border shadow-0">
                      <div class="m-4">
                        <h4 class="card-title mb-4">Your shopping cart</h4>
                        <?php if (empty($cartItems)): ?>
                            <p>Your cart is empty.</p>
                        <?php else: ?>
                            <form method="POST" action="shopping_cart.php">
                                <?php foreach ($cartItems as $item): ?>
                                    <div class="row gy-3 mb-4 align-items-center">
                                      <div class="col-lg-5">
                                        <div class="me-lg-5">
                                          <div class="d-flex align-items-center">
                                            <!-- Dynamically load the product image -->
                                            <?php if (isset($item['img']) && !empty($item['img'])): ?>
                                                <img src="admin/img/addproduct/<?php echo htmlspecialchars($item['img']); ?>" class="border rounded me-3" style="width: 96px; height: 96px;" alt="<?php echo htmlspecialchars($item['name']); ?>" />
                                            <?php else: ?>
                                                <img src="admin/img/addproduct/default.png" class="border rounded me-3" style="width: 96px; height: 96px;" alt="Default Image" />
                                            <?php endif; ?>
                                            <div>
                                              <a href="Product Coming Soon.php" class="text-decoration-none text-dark"><?php echo htmlspecialchars($item['name']); ?></a>
                                              <p class="text-muted"><?php echo htmlspecialchars($item['subtitle']); ?></p>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                      <div class="col-lg-2 col-sm-6 col-6 d-flex flex-row flex-lg-column flex-xl-row text-nowrap">
                                        <div>
                                          <select name="quantities[<?php echo $item['cart_id']; ?>]" class="form-select me-4" onchange="updateCart(this.form)">
                                              <?php for ($i = 1; $i <= 4; $i++): ?>
                                                  <option value="<?php echo $i; ?>" <?php echo $item['quantity'] == $i ? 'selected' : ''; ?>><?php echo $i; ?></option>
                                              <?php endfor; ?>
                                          </select>
                                        </div>
                                        <div>
                                          <text class="h6"><?php echo number_format($item['price'] * $item['quantity']); ?><span class="fw-bold ms-2 fs-6">MMK</span></text> <br />
                                          <small class="text-muted text-nowrap"><?php echo number_format($item['price']); ?><span class="ms-2">MMK</span> / per item</small>
                                        </div>
                                      </div>
                                      <div class="col-lg col-sm-6 d-flex justify-content-sm-center justify-content-md-start justify-content-lg-center justify-content-xl-end mb-2">
                                        <div class="float-md-end">
                                          <a href="shopping_cart.php?remove_id=<?php echo $item['cart_id']; ?>" class="custom-icon-color-remove icon-hover-remove"> Remove</a>
                                        </div>
                                      </div>
                                    </div>
                                <?php endforeach; ?>
                                <!-- Removed Update Quantities Button -->
                            </form>
                        <?php endif; ?>
                        <div class="border-top pt-4 mx-4 mb-4">
                          <p><i class="fas fa-truck text-muted fa-lg"></i> Free Delivery within 1-2 weeks</p>
                          <p class="text-muted">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- cart -->
                  <!-- summary -->
                  <div class="col-lg-3 py-4">
                    <div class="card mb-3 border shadow-0">
                      <div class="card-body">
                        <div class="d-flex justify-content-between">
                          <p class="mb-2">Total price:</p>
                          <p class="mb-2"><?php echo number_format($totalPrice); ?><span class="ms-2 fw-bold">MMK</span></p>
                        </div>
                        <div class="d-flex justify-content-between">
                          <p class="mb-2">Discount:</p>
                          <p class="mb-2 text-success">-<?php echo number_format($discountAmount); ?><span class="ms-2 fw-bold">MMK</span></p>
                        </div>
                        <div class="d-flex justify-content-between">
                          <p class="mb-2">TAX:</p>
                          <p class="mb-2"><?php echo number_format($taxAmount); ?><span class="ms-2 fw-bold">MMK</span></p>
                        </div>
                        <hr />
                        <div class="d-flex justify-content-between">
                          <p class="mb-2">Final Total:</p>
                          <p class="mb-2 fw-bold"><?php echo number_format($finalTotal); ?><span class="ms-2 fw-bold">MMK</span></p>
                        </div>
                        <div class="mt-3">
                          <a href="checkout.php" class="btn btn-success w-100 shadow-0 mb-2"> Make Purchase </a>
                          <a href="product.php" class="btn btn-light
