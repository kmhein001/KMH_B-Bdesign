<!-- Brand Navbar-->
<a class="navbar-brand" href="home.php">
    <img src="img/B&B-1.png" alt="Brand logo"
        width="70" height="70"><label class="customer-brand-name"> B&B DesignBuild<span style="color:gold">.</span></label>
</a>