<!-- TOP Navbar PHP -->
<div class="top-nav text-white py-2" id="home">  
    <div class="container d-flex justify-content-between align-content-center">
        <div>
            <p class="mb-0"> 
                <i class="bi bi-envelope-at"></i><a class="mx-3 link-light link-opacity-75 link-opacity-100-hover text-decoration-none" href="mailto:contact@yourcompanyname.com.mm">contact@B&BDesignBuild.com.mm</a></p>
            <p class="mb-0"> <i class="bi bi-telephone-outbound"></i><a class="mx-3 link-light link-opacity-75 link-opacity-100-hover text-decoration-none" href="tel:+95 9791045678">+95 9791045678</a></p>
        </div>
        <div class="social-icons">
                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="text-black"><i class="bi bi-facebook"></i></a>
                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="text-black"><i class="bi bi-twitter-x"></i></a>
                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="text-black"><i class="bi bi-instagram"></i></a>
                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="text-black"><i class="bi bi-tiktok"></i></a>
        </div>
    </div>
</div>