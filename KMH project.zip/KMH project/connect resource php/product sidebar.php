 <!-- Sidebar PHP-->
<div class="col-lg-3">
    <!-- Toggle button -->
    <button
        class="btn product-show mb-3 w-100 d-lg-none"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span>Show filter</span>
    </button>
    <!-- Collapsible wrapper -->
    <div class="collapse card d-lg-block mb-5" id="navbarSupportedContent">
        <div class="accordion" id="accordionPanelsStayOpenExample">
            <!-- Related Items Accordion -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#panelsStayOpen-collapseOne"
                            aria-expanded="true"
                            aria-controls="panelsStayOpen-collapseOne">
                            Related items
                    </button>
                </h2>
                <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne">
                    <div class="accordion-body">
                        <ul class="list-unstyled">
                            <li><a href="Product Coming Soon.html" class="text-dark">Brick Types</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Concrete Blocks</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Polymeric Sand</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Cleaners</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Cladding Materials</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Wall Panels</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Insulation Materials</a></li>
                            <li><a href="Product Coming Soon.html" class="text-dark">Geogrid & Fabric</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Brands Accordion -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#panelsStayOpen-collapseTwo"
                            aria-expanded="true"
                            aria-controls="panelsStayOpen-collapseTwo">
                            Brands
                    </button>
                </h2>
                <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse show" aria-labelledby="headingTwo">
                    <div class="accordion-body">
                        <div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked1" checked />
                                <label class="form-check-label" for="flexCheckChecked1">BrickWorks</label>
                                <span class="badge badge-secondary float-end">20</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked2" checked />
                                <label class="form-check-label" for="flexCheckChecked2">Concrete Block (CMU)</label>
                                <span class="badge badge-secondary float-end">25</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked3" checked />
                                <label class="form-check-label" for="flexCheckChecked2">Concrete Pavers</label>
                                <span class="badge badge-secondary float-end">30</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked4" checked />
                                <label class="form-check-label" for="flexCheckChecked2">Specialty Masonry Units</label>
                                <span class="badge badge-secondary float-end">5</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked5" checked />
                                <label class="form-check-label" for="flexCheckChecked2">Dura-Hold II</label>
                                <span class="badge badge-secondary float-end">27</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked6" checked />
                                <label class="form-check-label" for="flexCheckChecked2">Sleeve-It</label>
                                <span class="badge badge-secondary float-end">3</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked7" checked />
                                <label class="form-check-label" for="flexCheckChecked3">Snap Edge</label>
                                <span class="badge badge-secondary float-end">4</span>
                            </div>
                            <!-- Checked checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked8" checked />
                                <label class="form-check-label" for="flexCheckChecked4">EaCoChem</label>
                                <span class="badge badge-secondary float-end">8</span>
                            </div>
                            <!-- Default checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value=""  id="flexCheckChecked9" checked  />
                                <label class="form-check-label" for="flexCheckDefault">Techniseal</label>
                                <span class="badge badge-secondary float-end">6</span>
                            </div>
                            <!-- Default checkbox -->
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked10" checked  />
                                <label class="form-check-label" for="flexCheckDefault">Gator Maxx</label>
                                <span class="badge badge-secondary float-end">10</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Price Accordion -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#panelsStayOpen-collapseThree"
                            aria-expanded="false"
                            aria-controls="panelsStayOpen-collapseThree">
                            Price
                    </button>
                </h2>
                <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse show" aria-labelledby="headingThree">
                    <div class="accordion-body">
                        <div class="range">
                            <input type="range" class="form-range" id="customRange1" />
                        </div>
                        <div class="row mb-3">
                            <div class="col-6">
                                <p class="mb-0">Min</p>
                                <div class="form-outline">
                                    <input type="number" id="typeNumber" class="form-control" />
                                    <label class="form-label" for="typeNumber">500 <br><span class="fw-bold fs-6">MMK</span></label>
                                </div>
                            </div>
                            <div class="col-6">
                                <p class="mb-0">Max</p>
                                <div class="form-outline">
                                    <input type="number" id="typeNumber" class="form-control" />
                                    <label class="form-label" for="typeNumber">1,000,000 <br><span class="fw-bold fs-6">MMK</span></label>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn custom-apply-outline-color w-100 border border-secondary">Apply</button>
                    </div>
                </div>
            </div>
            <!-- Size Accordion -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFour">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#panelsStayOpen-collapseFour"
                            aria-expanded="false"
                            aria-controls="panelsStayOpen-collapseFour" >
                            Size & Dimensions
                    </button>
                </h2>
                <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse show" aria-labelledby="headingFour">
                    <div class="accordion-body">
                        <!-- Size options styled like bricks/blocks -->
                        <input type="checkbox" class="btn-check" id="btn-check1" checked autocomplete="off" />
                        <label class="btn btn-block-style mb-1" for="btn-check1">Small</label>
                
                        <input type="checkbox" class="btn-check" id="btn-check2" checked autocomplete="off" />
                        <label class="btn btn-block-style mb-1" for="btn-check2">Medium</label>
                
                        <input type="checkbox" class="btn-check" id="btn-check3" checked autocomplete="off" />
                        <label class="btn btn-block-style mb-1" for="btn-check3">Large</label>
                
                        <input type="checkbox" class="btn-check" id="btn-check4" checked autocomplete="off" />
                        <label class="btn btn-block-style mb-1" for="btn-check4">Extra Large</label>
                    </div>
                </div>
            </div>
            <!-- Ratings Accordion -->
            <div class="accordion-item">
                <h2 class="accordion-header" id="headingFive">
                    <button class="accordion-button"
                            type="button"
                            data-bs-toggle="collapse"
                            data-bs-target="#panelsStayOpen-collapseFive"
                            aria-expanded="false"
                            aria-controls="panelsStayOpen-collapseFive">
                            Ratings
                    </button>
                </h2>
                <div id="panelsStayOpen-collapseFive" class="accordion-collapse collapse show" aria-labelledby="headingFive">
                    <div class="accordion-body">
                        <!-- Star ratings checkboxes -->
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="ratingCheck1" checked />
                                <label class="form-check-label" for="ratingCheck1">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="ratingCheck2" checked />
                                <label class="form-check-label" for="ratingCheck3">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-half text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="ratingCheck3" checked />
                                <label class="form-check-label" for="ratingCheck4">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="ratingCheck4" checked />
                                <label class="form-check-label" for="ratingCheck5">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star-half text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="ratingCheck5" checked />
                                <label class="form-check-label" for="ratingCheck5">
                                    <i class="bi bi-star-fill text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                    <i class="bi bi-star text-warning"></i>
                                </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>