<?php
    $current_page = basename($_SERVER['PHP_SELF']);
    $active_login = ($current_page == 'login.php') ? 'active aria-current="page"' : '';
    $active_shopping_card = ($current_page == 'shopping card.php') ? 'active aria-current="page"' : '';
?>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container">
        <!-- Brand Navbar-->
        <?php include_once('connect resource php/Brand Navbar.php'); ?>
        <!--Toggler btn-->
        <button class="navbar-toggler" 
                type="button" 
                data-bs-toggle="offcanvas" 
                data-bs-target="#offcanvasNavbar" 
                aria-controls="offcanvasNavbar" 
                aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!--Navbar sidebar-->
        <div class="offcanvas offcanvas-start bg-dark text-white" 
            tabindex="-1" 
            id="offcanvasNavbar" 
            aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header text-white border-bottom">
                <h5 class="offcanvas-title" 
                    id="offcanvasNavbarLabel">Bootstrap</h5>
                <button type="button" 
                    class="btn-close btn-close-white" 
                    data-bs-dismiss="offcanvas" 
                    aria-label="Close">
                </button>
            </div>
            <!--navbar text row-->
            <div class="offcanvas-body d-flex flex-column flex-lg-row">
                <ul class="navbar-nav justify-content-center align-items-center flex-grow-1 pe-3">
                    <?php include_once('connect resource php/Navigation.php'); ?>
                </ul>
                <div class="d-flex flex-lg-row justify-content-center align-items-center gap-3">
                    <a href="login.php" data-bs-target="#lognin" class="btn btn-brand btn-brand-card border rounded <?php echo $active_login; ?>">Login</a>
                    <a href="shopping_cart.php" class="btn-brand-card border rounded px-3 d-flex align-items-center <?php echo $active_shopping_card; ?>"> <i class="bi bi-cart-fill"></i></a>
                </div>
            </div>
        </div>
    </div>                   
</nav>