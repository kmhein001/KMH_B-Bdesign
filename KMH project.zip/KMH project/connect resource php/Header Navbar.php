<!-- Modal -->
<?php include_once('modal.php'); ?> 
<!-- Header -->
<header>
    <!-- Top Navbar -->
    <?php include_once('Top Navbar.php'); ?> 
    <!-- Main Navbar-->                        
    <?php include_once('Main Navbar.php'); ?> 
</header>