<?php
// Define the current page
$current_page = basename($_SERVER['PHP_SELF']);

// Define the navigation links
$nav_links = array(
    'home.php' => 'Home',
    'blog.php' => array(
        'text' => 'Blog',
        'dropdown' => array(
            'House Design' => 'Coming Soon.php',
            'Brick Design' => 'Coming Soon.php',
            'Building Projects' => 'Coming Soon.php',
            'Concrete Block Design' => 'Coming Soon.php',
            'Another action' => 'Coming Soon.php',
            'Something else here' => '404 Error Page.php',
        ),
    ),
    'Product.php' => 'Product',
    'Service.php' => 'Service',
    'about.php' => 'About',
    'contact.php' => 'Contact',
);

// Generate the navigation links
foreach ($nav_links as $link => $text) {
    if (is_array($text)) {
        echo '<li class="nav-item dropdown btn-group">';
        echo '<a class="nav-link btn" href="' . $link . '">' . $text['text'] . '</a>';
        echo '<button type="button" class="btn text-white dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false">';
        echo '<span class="visually-hidden">Toggle Dropdown</span>';
        echo '</button>';
        echo '<ul class="dropdown-menu dropdown-menu-dark">';
        foreach ($text['dropdown'] as $dropdown_text => $dropdown_link) {
            echo '<li><a class="dropdown-item" href="' . $dropdown_link . '">' . $dropdown_text . '</a></li>';
        }
        echo '</ul>';
        echo '</li>';
    } else {
        $active = ($current_page == $link) ? 'active aria-current="page"' : '';
        echo '<li class="nav-item"><a class="nav-link ' . $active . '" href="' . $link . '">' . $text . '</a></li>';
    }
}
?>