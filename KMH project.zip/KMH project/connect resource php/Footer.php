<!-- Footer PHP -->
        <footer class="bg-dark text-white pt-5 pb-5">
            <div class="container text-center text-md-left">
                <div class="row text-center text-md-left">
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                        <a href="home.php" style="text-decoration:none; color: inherit; ">
                        <h5 class="text-uppercase mb-4 font-weight-bold text-warning"> B&B DesignBuild<span class="text-white">.</span></h5>
                        </a>
                        <p>B&B DesignBuild specializes in innovative Brick and Block construction solutions. 
                        Our name reflects our commitment to high-quality design and build services, combining traditional brick and block techniques with modern design principles. 
                        We offer comprehensive solutions from concept to completion, ensuring every project meets the highest standards of craftsmanship and durability.......</p>
                    </div>
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                    <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Our Offerings</h5>
                    <p><a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Innovative Design Solutions</a></p>
                    <p><a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Custom Building Services</a></p>
                    <p><a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Residential Renovations</a></p>
                    <p><a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Commercial Projects</a></p>
                    </div>
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Useful Links</h5>
                        <p>
                        <a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Help Center</a>
                        </p>
                        <p>
                            <a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Privacy and Confidentiality</a>
                        </p>
                        <p>
                            <a href="Coming Soon.php" class="text-white" style="text-decoration: none;">Terms and Conditions </a>
                        </p>
                        <p>
                            <a href="Coming Soon.php" class="text-white" style="text-decoration: none;">FAQ</a>
                        </p>
                    </div>
                    <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
                    <h5 class="text-uppercase mb-4 font-weight-bold text-warning">Contact Us!</h5>
                    <table class="table table-borderless custom-bg-transparent">
                        <tbody>
                            <tr>
                                <td class="custom-bg-transparent"><i class="bi bi-geo me-3"></i></td>
                                <td class="custom-bg-transparent">No.2 Highways road, East Dagon Myothit Township, Yangon</td>
                            </tr>
                            <tr>
                                <td class="custom-bg-transparent"><i class="bi bi-envelope-at me-3"></i></td>
                                <td class="custom-bg-transparent"><a class="link-light text-decoration-none" href="mailto:info@yourcompanyname.com.mm">info@B&BDesignBuild.com.mm</a></td>
                            </tr>
                            <tr>
                                <td class="custom-bg-transparent"><i class="bi bi-telephone-outbound me-3"></i></td>
                                <td class="custom-bg-transparent"><a class="link-light text-decoration-none" href="tel:+95 9791045678">+95 9791045678</a></td>
                            </tr>
                            <tr>
                                <td class="custom-bg-transparent"><i class="bi bi-alarm me-3"></i></td>
                                <td class="custom-bg-transparent">
                                    <h5 class="mb-3 text-light fw-bold">Opening Hours</h5>
                                    <table class="table table-borderless custom-bg-transparent">
                                    <tbody>
                                        <tr>
                                            <td class="custom-bg-transparent text-light fw-bold">Mon - Fri</td>
                                            <td class="custom-bg-transparent text-light opacity-75">10am - 5pm</td>
                                        </tr>
                                        <tr>
                                            <td class="custom-bg-transparent text-light fw-bold">Sat - Sun</td>
                                            <td class="custom-bg-transparent text-light opacity-75">10am - 2pm</td>
                                        </tr>
                                    </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                    <hr class="mb-4">
                    <div class="row d-flex justify-content-center">
                        <p> Copyright&copy;2024. All rights Reserved by: 
                            <a href="home.php" style="text-decoration: none;">
                                <strong class="text-warning">
                                <label style="Font-size:20px;"> B&B DesignBuild<span class="text-white">.</span></label>
                                </strong>
                            </a>
                        </p>
                    </div>
                    <div class="row d-flex justify-content-center">
                        <ul class="social-icons list-unstyled list-inline">
                            <li class="list-inline-item">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn-floating btn-sm text-black" style="font-size:23px;">
                                    <i class="bi bi-facebook"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn-floating btn-sm text-black" style="font-size:23px;">
                                    <i class="bi bi-twitter-x"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn-floating btn-sm text-black" style="font-size:23px;">
                                    <i class="bi bi-instagram"></i>
                                </a>
                            </li>
                            <li class="list-inline-item">
                                <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn-floating btn-sm text-black" style="font-size:23px;">
                                    <i class="bi bi-tiktok"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>