<?php
session_start();
include('connection.php');

// Get the current session ID
$session_id = session_id();

// Get product ID from the URL
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

// Set quantity (you can modify this based on your requirements, e.g., a default value of 1)
$quantity = 1; 

// Check if the product is already in the shopping cart
$checkQuery = "SELECT * FROM shopping_cart WHERE Session_ID = '$session_id' AND Product_ID = '$product_id'";
$checkResult = mysqli_query($conn, $checkQuery);

if (mysqli_num_rows($checkResult) > 0) {
    // Product already exists in the cart, update the quantity
    $updateQuery = "UPDATE shopping_cart SET Quantity = Quantity + $quantity WHERE Session_ID = '$session_id' AND Product_ID = '$product_id'";
    mysqli_query($conn, $updateQuery);
} else {
    // Insert new product into the shopping cart
    $insertQuery = "INSERT INTO shopping_cart (Session_ID, Product_ID, Quantity, Added_At) VALUES ('$session_id', '$product_id', '$quantity', NOW())";
    mysqli_query($conn, $insertQuery);
}

// Redirect back to the product page or wherever you want
header('Location: product.php');
exit();
?>
