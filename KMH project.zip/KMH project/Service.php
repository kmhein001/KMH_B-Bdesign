<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Head -->
        <?php include_once('connect resource php/head.php'); ?>  
    <!-- Link -->
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/bsb-overlay/bsb-overlay.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/ctas/cta-1/assets/css/cta-1.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/bsb-btn-circle/bsb-btn-circle.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/margin/margin.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/padding/padding.css">

  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    <!-- Service -->
    <section class="px-6" style="background-color: rgb(255, 255, 255);">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="px-5" style="background-color: rgb(16, 84, 112);">
              <div class="container">
                <div class="row">
                  <div class="col-12">
                    <div class="p-5" style="background-color: #f8f9fa;">
                      <div class="container">
                        <div class="row justify-content-md-center">
                          <div class="col-12">
                            <h1 class="fs-1 mb-6 text-black text-center text-uppercase">Service</h1>
                            <!-- Call To Action -->
                            <div class="bsb-cta-1 bsb-overlay" style="background-image: url(img/Customer-Service-1.png);">
                              <div class="container">
                                <div class="row">
                                  <div class="col-12 col-md-9 col-lg-8 col-xl-7 col-xxl-6 ps-6">
                                    <h2 class="fs-5 mb-3 text-white fw-bold text-uppercase">Our Services & Expertise</h2>
                                    <h2 class="display-6 text-white mb-4">Specialists in Construction and Building Materials, from Bricks to Concrete Blocks.</h2>
                                    <a href="Coming soon Service.php" class="btn bsb-btn-2xl btn-button-click rounded mb-0 text-nowrap">Explore Our Projects</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="py-3 py-md-5 py-xl-8">
                              <div class="container">
                                <div class="row justify-content-md-center">
                                  <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                                    <h2 class="mb-4 display-5 text-center">Our Expertise</h2>
                                    <p class="text-secondary mb-5 text-center lead fs-4">Providing comprehensive construction services, from foundation to finishing, with a focus on quality and craftsmanship.</p>
                                    <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
                                  </div>
                                </div>
                              </div>

                              <div class="container">
                                <div class="row">
                                  <div class="col-12">
                                    <div class="container-fluid">
                                      <div class="row gy-3 gy-md-4">
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-bricks text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Bricklaying Services</h4>
                                              <p class="mb-4 text-secondary">Expert bricklaying services for residential and commercial buildings, ensuring......</p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color bsb-btn-circle mt-5">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-building text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Concrete Block Construction</h4>
                                              <p class="mb-4 text-secondary">Our expertise in concrete block construction delivers strength and reliability for various building types.</p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color bsb-btn-circle mt-4">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-buildings-fill text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Project Management</h4>
                                              <p class="mb-4 text-secondary">Comprehensive project management services to oversee every phase of construction ..... </p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color bsb-btn-circle mt-5">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-tools text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Masonry Work</h4>
                                              <p class="mb-4 text-secondary">Skilled masonry work including brick, stone, and block laying to create lasting structures with precision.</p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color bsb-btn-circle mt-5">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-hammer text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Renovations & Remodeling</h4>
                                              <p class="mb-4 text-secondary">Specialized in renovations and remodeling services to modernize and enhance existing structures.</p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color btn-outline bsb-btn-circle mt-4">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                        <div class="col-12 col-md-6 col-lg-4">
                                          <div class="card border-dark">
                                            <div class="card-body text-center p-4 p-xxl-5" style="height: 380px;">
                                              <i class="bi bi-bar-chart-line-fill text-danger mb-4" style="font-size: 48px; color: currentColor;"></i>
                                              <h4 class="mb-4">Consultation Services</h4>
                                              <p class="mb-4 text-secondary">Offering professional consultation services to help plan, execute, and refine your building projects.</p>
                                              <a href="Coming soon Service.php" class="btn custom-btn-outline-color bsb-btn-circle mt-5">
                                                <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                              </a>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="py-5 py-xl-8">
                                <div class="container">
                                  <div class="row justify-content-md-center">
                                    <div class="col-12 col-md-10 col-lg-8 col-xl-7">
                                      <h2 class="display-5 mb-5 mb-xl-9 text-center">Combining Quality with Affordability in Every Project.</h2>
                                    </div>
                                  </div>
                                </div>
                                <div class="container">
                                  <div class="row">
                                    <div class="col-12">
                                      <div class="container-fluid bg-light border shadow">
                                        <div class="row">
                                          <div class="col-12 col-md-4 p-0">
                                            <div class="card border-0 bg-transparent">
                                              <div class="card-body text-center p-5">
                                                <i class="bi bi-clipboard-data-fill text-danger mb-4" style="font-size: 56px; color: currentColor;"></i>
                                                <h4 class="fw-bold text-uppercase mb-4">Planning & Strategy</h4>
                                                <p class="mb-4 text-secondary">Developing a strategic approach to construction that meets market needs and client expectations.</p>
                                                <a href="Coming soon Service.php" class="fw-bold text-decoration-none btn-button-click">
                                                  Learn More
                                                  <i class="bi bi-arrow-right-short mb-4" style="font-size: 20px; color: currentColor;"></i>
                                                </a>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="col-12 col-md-4 p-0 border-top border-bottom border-start border-end">
                                            <div class="card border-0 bg-transparent">
                                              <div class="card-body text-center p-5">
                                                <i class="bi bi-palette-fill text-danger mb-4" style="font-size: 56px; color: currentColor;"></i>
                                                <h4 class="fw-bold text-uppercase mb-4">Architectural Design</h4>
                                                <p class="mb-4 text-secondary">Creating innovative and practical design solutions for every type of construction project.</p>
                                                <a href="Coming soon Service.php" class="fw-bold text-decoration-none btn-button-click">
                                                  Learn More
                                                  <i class="bi bi-arrow-right-short mb-4" style="font-size: 20px; color: currentColor;"></i>
                                                </a>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="col-12 col-md-4 p-0">
                                            <div class="card border-0 bg-transparent">
                                              <div class="card-body text-center p-5">
                                                <i class="bi bi-gear-wide-connected text-danger mb-4" style="font-size: 56px; color: currentColor;"></i>
                                                <h4 class="fw-bold text-uppercase mb-4">Project <br> Execution</h4>
                                                <p class="mb-4 text-secondary">From blueprint to final build, managing all aspects of the construction process to ensure success.</p>
                                                <a href="Coming soon Service.php" class="fw-bold text-decoration-none btn-button-click">
                                                  Learn More
                                                  <i class="bi bi-arrow-right-short mb-4" style="font-size: 20px; color: currentColor;"></i>
                                                </a>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div class="py-5 py-xl-8">
                                <div class="container">
                                    <div class="row justify-content-md-center">
                                        <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                                            <h2 class="fs-6 text-secondary mb-2 text-uppercase text-center">Satisfied Clients</h2>
                                            <p class="display-5 mb-4 mb-md-5 text-center">Discover how our clients feel about our building and design services.</p>
                                            <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
                                        </div>
                                    </div>
                                </div>
                                <div class="container overflow-hidden">
                                    <div class="row gy-4 gy-md-0 gx-xxl-5">
                                        <div class="col-12 col-md-4">
                                            <div class="card border-0 border-bottom border-primary shadow-sm">
                                                <div class="card-body p-4 p-xxl-5" style="height: 600px;">
                                                    <figure>
                                                        <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="img/woman-1.gif" alt="A satisfied homeowner">
                                                        <figcaption>
                                                            <div class="bsb-ratings text-warning mb-3" data-bsb-star="5" data-bsb-star-off="0"></div>
                                                            <blockquote class="bsb-blockquote-icon mb-4">Our new home exceeded all expectations. The team transformed our ideas into a beautiful reality, delivering ahead of schedule and within our budget. We highly recommend their services for .... </blockquote>
                                                            <h4 class="mb-2">Anna Collins</h4>
                                                            <h5 class="fs-6 text-secondary mb-0">Homeowner</h5>
                                                        </figcaption>
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="card border-0 border-bottom border-primary shadow-sm">
                                                <div class="card-body p-4 p-xxl-5" style="height: 600px;">
                                                    <figure>
                                                        <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="img/man-1.gif" alt="A happy business owner">
                                                        <figcaption>
                                                            <div class="bsb-ratings text-warning mb-3" data-bsb-star="4" data-bsb-star-off="1"></div>
                                                            <blockquote class="bsb-blockquote-icon mb-4">The renovation of our office space was handled with great professionalism. The design was not only functional but also stylish. We’re thrilled with the end result and would recommend them for any commercial project.</blockquote>
                                                            <h4 class="mb-2">James Carter</h4>
                                                            <h5 class="fs-6 text-secondary mb-0">Business Owner</h5>
                                                        </figcaption>
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="card border-0 border-bottom border-primary shadow-sm">
                                                <div class="card-body p-4 p-xxl-5" style="height: 600px;">
                                                    <figure>
                                                        <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="img/woman-2.gif" alt="A pleased client">
                                                        <figcaption>
                                                            <div class="bsb-ratings text-warning mb-3" data-bsb-star="5" data-bsb-star-off="0"></div>
                                                            <blockquote class="bsb-blockquote-icon mb-4">From the initial consultation to the final touches, the team was exceptional. They understood our vision for our new community center and brought it to life with exceptional quality......</blockquote>
                                                            <h4 class="mb-2">Emily Wilson</h4>
                                                            <h5 class="fs-6 text-secondary mb-0">Project Manager</h5>
                                                        </figcaption>
                                                    </figure>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                              </div>                            
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
</body>
</html>



    <!--   -->