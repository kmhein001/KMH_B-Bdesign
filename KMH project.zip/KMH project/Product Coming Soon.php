<!DOCTYPE html>
<html lang="en">
  <head>
        <!-- Head -->
        <?php include_once('connect resource php/head.php'); ?>  
  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    <section class="p-2 p-md-3 p-xl-5" style="background-color: rgb(255, 255, 255);">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="container">
                        <div class="row">
                            <!-- sidebar -->
                            <?php include_once('connect resource php/product sidebar.php'); ?> 
                            <!-- content -->
                            <div class="col-lg-9" >
                                <header class="d-sm-flex align-items-center border-bottom mb-4 pb-3">
                                    <div class="ms-auto">
                                        <select class="form-select d-inline-block w-auto border pt-1">
                                            <option value="0">Best match</option>
                                            <option value="1">Recommended</option>
                                            <option value="2">High rated</option>
                                            <option value="3">Randomly</option>
                                        </select>
                                        <div class="btn-group shadow-0 border">
                                        <a href="Product.php" class="btn btn-light" title="List view">
                                            <i class="bi bi-list fa-lg"></i>
                                        </a>
                                        <a href="Product.php" class="btn btn-light active" title="Grid view">
                                            <i class="bi bi-grid fa-lg"></i>
                                        </a>
                                        </div>
                                    </div>
                                </header>
                                <div class="py-6 py-md-5 min-vh-100 d-flex justify-content-center align-items-center">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex flex-column justify-content-center align-items-center text-center " style="height:1000px;" >
                                                    <h2 class="d-flex flex-column align-items-center gap-2 ">
                                                    <img src="img/Coming soon.gif" width="500px" height="500px"  alt="coming soon">
                                                    </h2>
                                                    <h3 class="h2 mb-2">Oops! This page isn't available yet.</h3>
                                                    <p class="mb-5">The page you are trying to access is currently under construction. Please check back later.</p>
                                                    <a class="btn btn-brand bsb-btn-5xl rounded-pill px-5 fs-6 m-0" href="product.php" role="button">Back to Product</a>
                                                </div>
                                                <hr />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>            
                </div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
  </body>
</html>