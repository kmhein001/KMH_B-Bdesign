<!DOCTYPE html>
<html lang="en" >
  <head>
    <title>Product List</title>
    <?php include_once('connect php/link.php'); ?> 
    <link rel="stylesheet" href="css/custom menu.css">
    <script src="js/custom menu.js"></script>
  </head>
  <body translate="no" >
  <body>
    <?php include_once('connect php/header.php'); ?> 
    <section translate="no">
      <div class="container-fluid py-5">
        <div class="row">
          <div class="col-12">
            <div class="row p-3 d-flex justify-content-between my-3">
              <div class="col-3 d-flex justify-content-start mt-5">
                <a href="home.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
              </div>
              <div class="col-6 d-flex justify-content-center">
                <h1><span class="custom-text">Contact List</h1>
              </div>
              <div class="col-3"></div>
            </div>
          </div>
        </div>
        <br>
        <table class="kise my-5" >
          <colgroup>
            <col width="5%"> <!-- No column -->
            <col width="15%"> <!-- Name column -->
            <col width="30%"> <!-- Email column -->
            <col width="30%"> <!-- Phone column -->
            <col width="30%"> <!-- Subject column -->
            <col width="30%"> <!-- Message column -->
          </colgroup>
          <thead>
            <tr>
              <th><h1>No</h1></th>
              <th><h1>Name</h1></th>
              <th><h1>Email</h1></th>
              <th><h1>Phone</h1></th>
              <th><h1>Subject</h1></th>
              <th><h1>Message</h1></th>
            </tr>
          </thead>
          <tbody>
            <?php
              error_reporting(1);
              include('connection.php');
              $data="SELECT * FROM `contact` ORDER BY id DESC";
              $val=$con->query($data);
              $i = 1;
              if ($val->num_rows > 0) {
              while(list($id,$name,$email,$phone,$subject,$message) = mysqli_fetch_array($val)){
                  echo "<tr>";
                  echo "<td>".$i++."</td>";
                  echo "<td>".$name."</td>";
                  echo "<td>".$email."</td>";
                  echo "<td>".$phone."</td>";
                  echo "<td>".$subject."</td>";
                  echo "<td>".$message."</td>";
              }
              }else{
                  echo "<tr><td colspan='4' class='text-center'>
                 <b> No data available</b></td></tr>";
              }
            ?>		
          </tbody>
        </table>
      </div>
    </section>
    <?php include_once('connect php/footer.php');?> 
  </body>
</html>