<?php
include("connection.php");


$product_id = $_GET['id'];


$query = "SELECT img FROM productlist WHERE id='$product_id'";
$result = $con->query($query);
$data = mysqli_fetch_assoc($result);

if ($data) {
    $image_path = "img/addproduct/" . $data['img']; 

    
    $delete_query = "DELETE FROM productlist WHERE id='$product_id'";
    if ($con->query($delete_query)) {
       
        if (file_exists($image_path)) {
            unlink($image_path); 
        }
        header('Location: product.php');
        exit();
    } else {
        echo "Error deleting product: " . $con->error;
    }
} else {
    echo "Product not found.";
}
?>
