<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('connect php/link.php'); ?>
    <title>Add Product - B&B Design Building</title>
    <link rel="stylesheet" href="css/custom form.css">
</head>
<body>
    <?php include_once('connect php/header.php'); ?>
    <section>
        <div class="container-fluid py-5">
            <div class="row my-5">
                <div class="col-5 d-flex justify-content-center align-items-center">
                    <img src="img/admin image/add-product.png" width="600px" height="1200px" style="margin-left: 150px; border-radius: 20px; margin-top: 20px;" />
                </div>
                <div class="col-1"></div>
                <div class="col-5">      
                    <div class="container">
                        <div class="d-flex justify-content-between my-5">
                            <h1 class="custom-text">Add Product</h1>
                            <div class="header-buttons">
                                <a href="product.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
                            </div>
                        </div>
                        <?php
                            error_reporting(E_ALL); // Enable all error reporting
                            include('connection.php');
                            if (isset($_POST['sub'])) {
                                $product_name = mysqli_real_escape_string($con, $_POST['name']);
                                $product_subtitle = mysqli_real_escape_string($con, $_POST['subtitle']);
                                $product_price = $_POST['price']; // Assuming this is numeric
                                $product_discount = !empty($_POST['discount']) ? $_POST['discount'] : 0; // Set discount to 0 if not provided
                                $product_desc = mysqli_real_escape_string($con, $_POST['description']);
                                $product_shipping = mysqli_real_escape_string($con, $_POST['shipping']);
                                $image = $_FILES["image"]["name"];

                                // Check if price is numeric
                                if (!is_numeric($product_price)) {
                                    echo "<script>alert('Price must be numeric.');</script>";
                                } else {
                                    // Corrected SQL query with backticks
                                    $query = mysqli_query($con, "INSERT INTO productlist (`Name`, `Subtitle`, `Price`, `Discount`, `Description`, `Shipping`, `img`) 
                                    VALUES ('$product_name', '$product_subtitle', $product_price, $product_discount, '$product_desc', '$product_shipping', '$image')");
                                    
                                    if ($query) {
                                        move_uploaded_file($_FILES["image"]["tmp_name"], "img/addproduct/" . $image);
                                        echo "<script>alert('Product has been added.');</script>";
                                        echo "<script>window.location.href = 'product.php'</script>";   
                                    } else {
                                        echo "<script>alert('Something Went Wrong. Please try again.');</script>";  	
                                    }
                                }
                            }
                        ?>
                        <div id="addProductForm">
                            <form method="POST" enctype="multipart/form-data">
                                <label for="name">Name:</label>
                                <input type="text" id="name" name="name" required><br>

                                <label for="subtitle">Subtitle:</label>
                                <input type="text" id="subtitle" name="subtitle" required><br>

                                <label for="price">Price:</label>
                                <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" type="number" id="price" name="price" required step="0.01"><br>

                                <label for="discount">Discount:</label>
                                <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" type="number" id="discount" name="discount" step="0.01" value="0"><br>

                                <label for="description">Description:</label>
                                <textarea id="description" name="description" required></textarea><br>
                                
                                <label for="shipping">Shipping:</label>
                                <select class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" id="shipping" name="shipping" required>
                                    <option value="">Select Shipping Option</option>
                                    <option value="Paid Shipping">Paid Shipping</option>
                                    <option value="Free Shipping">Free Shipping</option>
                                </select><br>

                                <label for="image">Image:</label>
                                <input type="file" id="image" name="image" required><br>
                                <div class="d-flex justify-content-center">
                                    <button type="submit" name="sub">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-1"></div>
            </div>
        </div>
    </section>
    <?php include_once('connect php/footer.php');?> 
</body>
</html>
