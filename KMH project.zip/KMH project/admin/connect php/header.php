<header>
    <nav class="navbar navbar-dark sticky-top" style="background-color: #013d56;">
        <div class="container d-flex justify-content-center align-items-center">
        <a class="navbar-brand text-center" href="home.php">
            <div class="text-center">
            <img src="img/brand/B&B-1.png" alt="Brand logo" width="200" height="200"
                style="border: 2px solid #ffd700; 
                    box-shadow: 0 0 200px rgba(255, 215, 0, 0.5);
                    border-radius:30px;
                    padding:20px;
                    margin: 30px 0px;"><br>
            <label class="h1 fw-bold" 
                    style="font-size: 60px; text-shadow: 
                        5px -5px 5px rgba(135, 1, 1, 0.5); 
                        padding: 10px;"> 
                        B&B DesignBuild
                        <span style="color:gold">.</span>
            </label>
            </div>
        </a>
        </div>                   
    </nav>
</header>