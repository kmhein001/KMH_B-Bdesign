<footer class="text-white py-5" style="background-color: #013d56;">
  <div class="container text-center text-md-left">
    <div class="row text-center text-md-left">
      <div class="row d-flex justify-content-center">
        <p> Copyright&copy;2024. All Rights Reserved. Design by: 
          <a href="home.php" style="text-decoration: none;">
            <strong class="text-warning">
            <label style="Font-size:20px;"> B&B DesignBuild Kaung Myat Hein<span class="text-white">.</span></label>
            </strong>
          </a>
        </p>
      </div>
    </div>
  </div>
</footer>