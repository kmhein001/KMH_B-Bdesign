<?php
include("connection.php");

// Prepare the delete statement
$blog_id = $_GET['id'];


$query = "SELECT img FROM bloglist WHERE id='$blog_id'";
$result = $con->query($query);
$data = mysqli_fetch_assoc($result);
   

if ($data) {
    $image_path = "img/addblog/" . $data['img']; 

    
    $delete_query = "DELETE FROM bloglist WHERE id='$blog_id'";
    if ($con->query($delete_query)) {
       
        if (file_exists($image_path)) {
            unlink($image_path); 
        }
        header('Location: blog.php');
        exit();
    } else {
        echo "Error deleting blog: " . $con->error;
    }
} else {
    echo "Blog not found.";
}
?>
