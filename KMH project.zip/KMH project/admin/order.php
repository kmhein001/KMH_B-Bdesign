<?php
// Turn on error reporting for debugging
error_reporting(E_ALL);

// Include database connection
include('connection.php');

// Delete order if 'id' is passed in the URL
if (isset($_GET['id'])) {
    // Sanitize the 'id' parameter to prevent SQL injection
    $id = intval($_GET['id']);
    
    // Execute the delete query
    $q = "DELETE FROM `orders` WHERE id = '$id'";
    
    if ($con->query($q) === TRUE) {
        // Redirect back to the order page after deletion
        header('location:order.php');
        exit;
    } else {
        echo "Error deleting record: " . $con->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Order</title>
    <?php include_once('connect php/link.php'); ?>
    <link rel="stylesheet" href="css/custom menu.css">
    <script src="js/custom menu.js"></script>
</head>
<body>
    <?php include_once('connect php/header.php'); ?>
    
    <section translate="no">
        <div class="container-fluid py-5">
            <div class="row">
                <div class="col-12">
                    <div class="row p-3 d-flex justify-content-between my-3">
                        <div class="col-3 d-flex justify-content-start mt-5">
                            <a href="home.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm">&lt; Back</a>
                        </div>
                        <div class="col-6 d-flex justify-content-center">
                            <h1><span class="custom-text">Order List</h1>
                        </div>
                        <div class="col-3"></div>
                    </div>
                </div>
            </div>
            
            <br>
            
            <table class="kise my-5" >
                <colgroup>
                    <col width="10%"> <!-- No column -->
                    <col width="20%"> <!-- Name column -->
                    <col width="15%"> <!-- Phone column -->
                    <col width="20%"> <!-- Address column -->
                    <col width="15%"> <!-- Price column -->
                    <col width="15%"> <!-- Action column -->
                </colgroup>
                <thead>
                    <tr>
                        <th><h1>No</h1></th>
                        <th><h1>Name</h1></th>
                        <th><h1>Phone</h1></th>
                        <th><h1>Address</h1></th>
                        <th><h1>Price</h1></th>
                        <th><h1>Item View</h1></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Fetch orders from the database
                    $data = "SELECT * FROM `orders` ORDER BY id DESC"; // Correct column name to 'id'
                    $val = $con->query($data);
                    $i = 1; // Initialize a counter for numbering the orders

                    // Check if any rows are returned
                    if ($val && $val->num_rows > 0) {
                        // Loop through each order and display it in a table row
                        while ($row = $val->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $i++ . "</td>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";         
                            echo "<td>" . htmlspecialchars($row['phone']) . "</td>";        
                            echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['total_price']) . " MMK</td>";
                            
                            // Delete button
                            echo "<td><a href='order.php?id=" . $row['id'] . "' class='btn btn-outline-danger' style='border-radius:20px; margin:10px'><i class='bi bi-trash' style='font-size: 2rem;'></i></a></td>";
                            echo "</tr>";
                        }
                    } else {
                        // If no orders found, display a message
                        echo "<tr><td colspan='7' class='text-center'><b>No data available</b></td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>
    
    <?php include_once('connect php/footer.php'); ?>
</body>
</html>

<?php
// Close the database connection
$con->close();
?>
