<!DOCTYPE html>
<html lang="en" >
  <head>
    <title>Product List</title>
    <?php include_once('connect php/link.php'); ?> 
    <link rel="stylesheet" href="css/custom menu.css">
    <script src="js/custom menu.js"></script>
  </head>
  <body>
    <?php include_once('connect php/header.php'); ?> 
    <section translate="no">
      <div class="container-fluid py-5">
        <div class="row">
          <div class="col-12">
            <div class="row p-3 d-flex justify-content-between my-3">
              <div class="col-3 d-flex justify-content-start mt-5">
                <a href="home.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
              </div>
              <div class="col-6 d-flex justify-content-center">
                <h1><span class="custom-text">Product List</h1>
              </div>
              <div class="col-3 d-flex justify-content-end mt-5">
                <a href="add-product.php" id="addButton" class="btn btn-success text-light rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-success lh-sm shadow-md">+ Add Product</a>
              </div>
            </div>
          </div>
        </div>
        <br>
        <table class="kise my-5" >
          <colgroup>
            <col width="2%"> <!-- No column -->
            <col width="5%"> <!-- Name column -->
            <col width="2%"> <!-- Subtitlecolumn -->
            <col width="5%"> <!-- Price column -->
            <col width="5%"> <!-- Discount column -->
            <col width="10%"> <!-- Description column -->
            <col width="3%"> <!-- Shipping column -->
            <col width="15%"> <!-- Image column -->
            <col width="15%"> <!-- Action column -->
            <col width="15%"> <!-- Action column -->
          </colgroup>
          <thead>
            <tr>
              <th><h1>No</h1></th>
              <th><h1>Name</h1></th>
              <th><h1>Subtitle</h1></th>
              <th><h1>Price</h1></th>
              <th><h1>Discount</h1></th>
              <th><h1>Description</h1></th>
              <th><h1>Shipping</h1></th>
              <th><h1>Image</h1></th>
              <th colspan="2"><h1>Action</h1></th>
            </tr>
          </thead>
          <tbody>
            <?php
              error_reporting(1);
              include('connection.php');
              $data = "SELECT * FROM productlist ORDER BY id DESC";
              $val = $con->query($data);
              $i = 1;
              if ($val->num_rows > 0) {
                  while (list($id, $name, $subtitle, $price, $discount, $dis, $ship, $img) = mysqli_fetch_array($val)) {
                      echo "<tr>";
                      echo "<td>".$i++."</td>";
                      echo "<td>".$name."</td>";
                      echo "<td>".$subtitle."</td>"; 
                      echo "<td>".$price."</td>";
                      echo "<td>".$discount."</td>"; 
                      echo "<td>".$dis."</td>";
                      echo "<td>".$ship."</td>";
                      echo "<td><img src='./img/addproduct/$img' height='100' width='100' style='border-radius:20px;' /></td>";
                      echo "<td><a href='delete-product.php?id=$id&img=$img' class='btn btn-outline-danger' style='border-radius:20px; margin:10px'><i class='bi bi-trash' style='font-size: 2rem;'></i></a></td>";
                      echo "<td><a href='edit-product.php?id=$id' class='btn btn-outline-primary' style='border-radius:20px; margin:10px'><i class='bi bi-pencil' style='font-size: 2rem;'></i></a></td>";
                      echo "</tr>";
                    }
                    } else {
                      echo "<tr><td colspan='12' class='text-center'><b>No data available</b></td></tr>";
                    }
            ?>		
          </tbody>
        </table>
      </div>
    </section>
    <?php include_once('connect php/footer.php');?> 
  </body>
</html>