<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include_once('connect php/link.php'); ?>
        <title>Add Blog - B&B Design Building </title>
        <link rel="stylesheet" href="css/custom form.css">
    </head>
    <body>
        <?php include_once('connect php/header.php'); ?>
        <section>
             <div class="container-fluid py-5">
                <div class="row my-5">
                    <div class="col-5 d-flex justify-content-center align-items-center">
                        <img src="img/admin image/add-blog.png" width="600px" height="800px" style="margin-left: 150px;
                            border-radius: 20px; margin-top: 20px; " />
                    </div>
                    <div class="col-1"></div>
                    <div class="col-5">      
                        <div class="container">
                            <div class="d-flex justify-content-between my-5">
                                <h1 class="custom-text">Add Blog</h1>
                                <div class="header-buttons">
                                <a href="blog.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
                                </div>
                            </div>
                            <?php
                                error_reporting(1);
                                include('connection.php');

                                if (isset($_POST['sub'])) {
                                    $blog_name = mysqli_real_escape_string($con, $_POST['name']);
                                    $blog_title = mysqli_real_escape_string($con, $_POST['title']);
                                    $blog_date = mysqli_real_escape_string($con, $_POST['date']);
                                    $blog_desc = mysqli_real_escape_string($con, $_POST['description']);
                                    $image = $_FILES["image"]["name"];

                                    // Correcting the SQL statement
                                    $query = mysqli_query($con, "INSERT INTO bloglist(`Name`, `Title`, `Date`, `Description`, `img`)
                                                                VALUES ('$blog_name', '$blog_title', '$blog_date', '$blog_desc', '$image')");

                                    if ($query) {
                                        move_uploaded_file($_FILES["image"]["tmp_name"], "img/addblog/" . $image);
                                        echo "<script>alert('Blog has been added.');</script>"; 
                                        echo "<script>window.location.href = 'blog.php'</script>";   
                                    } else {
                                        echo "<script>alert('Something Went Wrong. Please try again.');</script>";  	
                                    }
                                }
                                ?>

                            <div id="addBlogForm">
                                <form method="POST" enctype="multipart/form-data">
                                    <label for="name">Name:</label>
                                    <input type="text" id="name" name="name" required><br>

                                    <label for="title">Title:</label>
                                    <input type="text" id="title" name="title" required><br>

                                    <label for="date">Date:</label>
                                    <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; /* Set the same background color */
                                            border: 2px solid red;" type="date" id="date" name="date" required><br>

                                    <label for="description">Description:</label>
                                    <textarea id="description" name="description" required></textarea><br>

                                    <label for="image">Image:</label>
                                    <input type="file" id="image" name="image" required><br>

                                    <div class="d-flex justify-content-center">
                                        <button type="submit" name="sub">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-1"></div>
                </div>
            </div>
        </section>
        <?php include_once('connect php/footer.php');?> 
    </body>
</html>
<style>

    