<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include_once('connect php/link.php'); ?>
        <title>Edit Blog - B&B Design Building </title>
        <link rel="stylesheet" href="css/custom form.css">
    </head>
    <body>
        <?php include_once('connect php/header.php'); ?>
        <section>
             <div class="container-fluid py-5">
                <div class="row my-5">
                    <div class="col-5 d-flex justify-content-center align-items-center">
                        <img src="img/admin image/add-blog.png" width="600px" height="800px" style="margin-left: 150px;
                            border-radius: 20px; margin-top: 20px; " />
                    </div>
                    <div class="col-1"></div>
                    <div class="col-5">      
                        <div class="container">
                            <div class="d-flex justify-content-between my-5">
                                <h1 class="custom-text">Edit Blog</h1>
                                <div class="header-buttons">
                                <a href="blog.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
                                </div>
                            </div>
                            <?php
                                error_reporting(E_ALL); // Display errors for debugging
                                include('connection.php');

                                $id = (int)$_GET['id']; // Ensure $id is an integer
                                $val = $con->query("SELECT * FROM bloglist WHERE id=$id");
                                $data = mysqli_fetch_array($val);
                                
                                if (isset($_POST['sub'])) {
                                    $blog_name = mysqli_real_escape_string($con, $_POST['name']);
                                    $blog_title = mysqli_real_escape_string($con, $_POST['title']);
                                    $blog_date = mysqli_real_escape_string($con, $_POST['date']);
                                    $blog_desc = mysqli_real_escape_string($con, $_POST['description']);
                                    $image = $_FILES["image"]["name"];
                                    
                                    // Use prepared statements to update the blog entry
                                    $stmt = $con->prepare("UPDATE bloglist SET Name=?, Title=?, Date=?, Description=? WHERE id=?");
                                    $stmt->bind_param("ssssi", $blog_name, $blog_title, $blog_date, $blog_desc, $id);
                                    
                                    if ($stmt->execute()) {
                                        if (!empty($image)) { // Optional: handle image upload if provided
                                            move_uploaded_file($_FILES["image"]["tmp_name"], "img/add/blog/" . $image);
                                        }
                                        header('location:blog.php');
                                        exit(); // Ensure no further code is executed
                                    } else {
                                        echo "<script>alert('Something Went Wrong: " . $stmt->error . ".');</script>";  
                                    }
                                    $stmt->close(); // Close the prepared statement
                                }
                            ?>
                            <div id="addBlogForm">
                                <form method="POST" enctype="multipart/form-data">
                                    <label for="name">Name:</label>
                                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($data['Name']); ?>" required><br>

                                    <label for="title">Title:</label>
                                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($data['Title']); ?>" required><br>

                                    <label for="date">Date:</label>
                                    <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; /* Set the same background color */
                                            border: 2px solid red;" type="date" id="date" name="date" value="<?php echo htmlspecialchars($data['Date']); ?>" required><br>

                                    <label for="description">Description:</label>
                                    <textarea id="description" name="description" required><?php echo htmlspecialchars($data['Description']); ?></textarea><br>

                                    <div class="d-flex justify-content-center">
                                        <button type="submit" name="sub">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-1"></div>
                </div>
            </div>
        </section>
        <?php include_once('connect php/footer.php');?> 
    </body>
</html>
