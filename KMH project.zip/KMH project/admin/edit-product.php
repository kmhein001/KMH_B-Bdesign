<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include_once('connect php/link.php'); ?>
        <title>Edit Product - B&B Design Building </title>
        <link rel="stylesheet" href="css/custom form.css">
    </head>
    <body>
        <?php include_once('connect php/header.php'); ?>
        <section>
            <div class="container-fluid py-5">
                <div class="row my-5">
                    <div class="col-5 d-flex justify-content-center align-items-center">
                        <img src="img/admin image/add-product.png" width="600px" height="800px" style="margin-left: 150px;
                            border-radius: 20px; margin-top: 20px; " />
                    </div>
                    <div class="col-1"></div>
                    <div class="col-5">      
                        <div class="container">
                            <div class="d-flex justify-content-between my-5">
                                <h1 class="custom-text">Edit Product</h1>
                                <div class="header-buttons">
                                <a href="product.php" id="addButton2" class="btn btn-danger text-white rounded fs-sm-5 fw-bold pt-3 pb-3 px-3 text-uppercase hover-danger letter-spacing-1 shadow-sm"> &lt; Back </a>
                                </div>
                            </div>
                            <?php
                                error_reporting(1);
                                include('connection.php');

                                $id = $_GET['id'];
                                $val = $con->query("SELECT * FROM productlist WHERE id=$id");
                                $data = mysqli_fetch_array($val);

                                if (isset($_POST['sub'])) {
                                    $product_name = mysqli_real_escape_string($con, $_POST['name']);
                                    $product_subtitle = mysqli_real_escape_string($con, $_POST['subtitle']);
                                    $product_price = $_POST['price'];
                                    $product_discount = !empty($_POST['discount']) ? $_POST['discount'] : 0; // Default to 0 if not provided
                                    $product_desc = mysqli_real_escape_string($con, $_POST['description']);
                                    $product_shipping = mysqli_real_escape_string($con, $_POST['shipping']);
                                    
                                    // SQL query to update the product
                                    $q = "UPDATE productlist SET 
                                        Name='$product_name',
                                        Subtitle='$product_subtitle',
                                        Price='$product_price',
                                        Discount='$product_discount',
                                        Description='$product_desc',
                                        Shipping='$product_shipping' 
                                        WHERE id=$id";
                                    
                                    if ($con->query($q)) {
                                        echo "<script>alert('Product updated successfully.');</script>";
                                        echo "<script>window.location.href = 'product.php';</script>";
                                    } else {
                                        echo "<script>alert('Failed to update product. Please try again.');</script>";
                                    }
                                }
                            ?>
                            <div id="addProductForm">
                                <form method="POST" enctype="multipart/form-data">
                                    <label for="name">Name:</label>
                                    <input type="text" id="name" name="name" value="<?php echo $data['Name']; ?>" required><br>

                                    <label for="subtitle">Subtitle:</label>
                                    <input type="text" id="subtitle" name="subtitle" value="<?php echo $data['Subtitle']; ?>" required><br>

                                    <label for="price">Price:</label>
                                    <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" type="number" id="price" name="price" value="<?php echo $data['Price']; ?>" required step="0.01"><br>

                                    <label for="discount">Discount:</label>
                                    <input class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" type="number" id="discount" name="discount" value="<?php echo $data['Discount']; ?>" step="0.01"><br>

                                    <label for="description">Description:</label>
                                    <textarea id="description" name="description" required><?php echo $data['Description']; ?></textarea><br>

                                    <label for="shipping">Shipping:</label>
                                    <select class="form-control ms-2 py-3 w-50" style="background: whitesmoke; border: 2px solid red;" id="shipping" name="shipping" required>
                                        <option value="">Select Shipping Option</option>
                                        <option value="Paid Shipping" <?php echo ($data['Shipping'] == 'Paid Shipping') ? 'selected' : ''; ?>>Paid Shipping</option>
                                        <option value="Free Shipping" <?php echo ($data['Shipping'] == 'Free Shipping') ? 'selected' : ''; ?>>Free Shipping</option>
                                    </select><br>

                                    <div class="d-flex justify-content-center">
                                        <button type="submit" name="sub">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-1"></div>
                </div>
            </div>
        </section>
        <?php include_once('connect php/footer.php');?> 
    </body>
</html>