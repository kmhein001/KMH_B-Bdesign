<?php
include("connection.php");

// Check if the 'id' is set and not empty
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Sanitize the id
    $id = mysqli_real_escape_string($con, $_GET['id']);
    
    // Delete the record with the corresponding ID
    $q = "DELETE FROM `orders` WHERE `ID` = '$id'";

    if ($con->query($q) === TRUE) {
        // Redirect back to order page after deletion
        header('Location: order.php');
        exit(); // Prevent further code execution after redirect
    } else {
        echo "Error deleting record: " . $con->error;
    }
} else {
    echo "No ID provided.";
}
?>
