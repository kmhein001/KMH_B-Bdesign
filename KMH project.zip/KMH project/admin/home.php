<!DOCTYPE html>
<html lang="en">
<head>
    <?php include_once('connect php/link.php'); ?> 
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/Admin Dashboard Home.css">
</head>
  <body>
    <?php include_once('connect php/header.php'); ?>
    <main>
      <section class="p-5" style="background-color: #091B29; height: auto;">
        <div class="container-fluid">
          <div class="row">
            <div class="col-3"></div>
            <div class="col-6">
              <div class="text-center p-4" style="background-color: #cf6112; border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);">
                <h1 class="my-4 fw-bold text-white" style="font-size: 36px; animation: fadeIn 1s ease-in;">Welcome, Admin!</h1>
                <h3 class="my-4 fw-normal text-white" style="font-size: 24px; animation: fadeIn 1.5s ease-in;">You can customize 4 menus below!</h3>
              </div>
            </div>
            <div class="row py-5">
              <div class="col-2"></div>
              <div class="col-3">   
                <center>
                  <a href="product.php" class="menu-link">
                    <img src="img/admin image/product list.png" class="menu-image" />
                    <p class="menu-text">product list</p>
                  </a>
                </center>
              </div>
              <div class="col-2"></div>
              <div class="col-3"> 
                <center>
                  <a href="blog.php" class="menu-link">
                    <img src="img/admin image/blog.png" class="menu-image" />
                    <p class="menu-text">blog list</p>
                  </a>
                </center>
              </div>
              <div class="col-2"></div>
            </div>
            <br>
            <div class="row">
              <div class="col-2"></div>
              <div class="col-3">
                <center>
                  <a href="order.php" class="menu-link">
                    <img src="img/admin image/Order.png" class="menu-image" />
                    <p class="menu-text">order list</p>
                  </a>
                </center>
              </div>
              <div class="col-2"></div>
              <div class="col-3">
                <center>
                  <a href="message.php" class="menu-link">
                    <img src="img/admin image/Message.png" class="menu-image" />
                    <p class="menu-text">message list</p>
                  </a>
                </center>
              </div>
              <div class="col-2"></div>
            </div>
          </div>
          <br>
          <center>
            <a role="button" class="btn btn-danger logout-button" href="index.php">Log Out</a>
          </center>
          <br>
        </div>
      </section>
    </main>
    <?php include_once('connect php/footer.php'); ?>
  </body>
</html>
