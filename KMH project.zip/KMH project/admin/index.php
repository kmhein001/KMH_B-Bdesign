
<!DOCTYPE html>
<html>
<head>
    <?php include_once('connect php/link.php'); ?> 
    <title>B&BDesign Login</title>
    <link rel="stylesheet" href="css/admin login design.css">
</head>
    <body>
        <div class="body-bg"></div>
        <div class="wrapper">
            <div class="form-container">
                <?php
                if (isset($_GET['submit'])) {
                    $eid = $_GET['Username'];
                    $pass = $_GET['Password'];
                    if ($eid == '' || $pass == '') {
                        echo "<p class=\"error-message\">Please fill Username or Password</p>";
                    } else {
                        if ($eid == "B&Bdesign" && $pass == "4774") {
                            header('location:home.php');
                        } else {
                            echo "<p class=\"error-message\">Username or Password Wrong!</p>";
                        }
                    }
                }
                ?>
                <form class="form">
                    <h1 class="title">Admin</h1>
                    <div class="inp">
                        <input type="text" name="Username" class="input" placeholder="Username">
                        <i class="bi bi-person"></i>
                    </div>
                    <div class="inp">
                        <input type="password" name="Password" class="input" placeholder="Password">
                        <i class="bi bi-lock"></i>
                    </div>
                    <button type="submit" class="submit" name="submit">Login</button>
                </form>
            </div>
            <div class="banner">
            <a class="navbar-brand" href="home.php">
                <img src="img/brand/B&B-1.png" alt="Brand logo" width="200" height="150" class="my-2">
                <h1 class="wel_text">B&B Design</h1><br>
                <h1 class="wel_text">Build</h1><br>
                <p class="para"></p>
            </div>
        </div>
    </body>
</html>