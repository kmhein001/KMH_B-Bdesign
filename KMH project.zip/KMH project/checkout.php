<?php
session_start();
include('connection.php');

// Get the current session ID
$session_id = session_id();

// Fetch cart items
$cartQuery = "SELECT sc.id as cart_id, p.id as product_id, p.name, p.price, p.discount, sc.quantity, p.img
             FROM shopping_cart sc
             JOIN productlist p ON sc.product_id = p.id
             WHERE sc.session_id = '$session_id'";
$cartResult = mysqli_query($conn, $cartQuery);

// Check if the query was successful
if (!$cartResult) {
    die("Error fetching cart items: " . mysqli_error($conn)); // Display error
}

// Calculate total
$grandTotal = 0;
while ($row = mysqli_fetch_assoc($cartResult)) {
    $totalPrice = ($row['price'] - $row['discount']) * $row['quantity'];
    $grandTotal += $totalPrice;
}

// Handle purchase action
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect user details
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    
    // Insert order into orders table
    $orderQuery = "INSERT INTO orders (session_id, name, phone, address, total_price) VALUES ('$session_id', '$name', '$phone', '$address', '$grandTotal')";
    
    if (mysqli_query($conn, $orderQuery)) {
        $order_id = mysqli_insert_id($conn);
        
        // Reset cart result pointer for inserting order items
        mysqli_data_seek($cartResult, 0);
        
        while ($row = mysqli_fetch_assoc($cartResult)) {
            $product_id = $row['product_id'];
            $quantity = $row['quantity'];
            $price = $row['price'] - $row['discount']; // Adjust price based on discount

            // Check if the item already exists in the order_items table
            $checkQuery = "SELECT * FROM order_items WHERE order_id = '$order_id' AND product_id = '$product_id'";
            $checkResult = mysqli_query($conn, $checkQuery);

            if (mysqli_num_rows($checkResult) > 0) {
                // Item exists, update the quantity
                $updateQuery = "UPDATE order_items SET quantity = quantity + $quantity WHERE order_id = '$order_id' AND product_id = '$product_id'";
                mysqli_query($conn, $updateQuery);
            } else {
                // Item does not exist, insert new item
                $itemQuery = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ('$order_id', '$product_id', '$quantity', '$price')";
                mysqli_query($conn, $itemQuery);
            }
        }
        
        // Clear the shopping cart
        $clearCartQuery = "DELETE FROM shopping_cart WHERE session_id = '$session_id'";
        mysqli_query($conn, $clearCartQuery);
        
        // Redirect to thank you page
        header('Location: thank_you.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Checkout</title>
    <?php include_once('connect resource php/head.php'); ?> 
    <link rel="stylesheet" href="css/custom menu.css">
    <style>
        .checkout-header {
            margin-bottom: 30px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
        }

        .checkout-item {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 10px;
        }

        .checkout-item img {
            width: 100px; 
            height: 100px; 
            margin-right: 10px; 
            object-fit: cover; 
        }

        .checkout-item-details {
            padding-left: 10px; 
            text-align: center; /* Center align the product name */
        }

        .total-price {
            margin-top: 20px;
            font-size: 1.5rem;
            font-weight: bold;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2);
        }

        .form-control {
            border-radius: 5px;
        }

        .btn-success {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 1.1rem;
        }

        .checkout-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .checkout-item-price {
            padding-left: 10px; /* Optional: Add some spacing from the text */
        }

        .product-name {
            font-weight: bold; /* Optional: make the product name bold */
        }

        .quantity {
            margin-left: 5px; /* Space between name and quantity */
        }
    </style>
</head>
<body>
    <?php include_once('connect resource php/Header Navbar.php'); ?>

    <section class="py-5">
        <div class="container">
            <h2 class="checkout-header text-center">Checkout</h2>
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <?php if (isset($cartResult) && mysqli_num_rows($cartResult) > 0): ?>
                            <h2>Your Cart Items:</h2>
                            <div class="row">
                                <?php 
                                mysqli_data_seek($cartResult, 0);
                                while ($item = mysqli_fetch_assoc($cartResult)) {
                                    $itemTotalPrice = ($item['price'] - $item['discount']) * $item['quantity'];
                                    ?>
                                    <div class="col-12 mb-3"> 
                                        <div class="checkout-item d-flex justify-content-between align-items-center"> 
                                            <div class="checkout-item-image">
                                                <img src="admin/img/addproduct/<?php echo htmlspecialchars($item['img']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="img-fluid"> 
                                            </div>
                                            <div class="checkout-item-details text-center flex-grow-1">
                                                <div class="d-flex justify-content-center align-items-center"> <!-- Use Flexbox for horizontal alignment -->
                                                    <span class="product-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                                    <span class="quantity ms-2">(x<?php echo $item['quantity']; ?>)</span> <!-- Added margin to the left -->
                                                </div>
                                            </div>
                                            <div class="checkout-item-price text-end">
                                                <span><?php echo number_format($itemTotalPrice); ?> MMK</span>
                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                }
                                ?>
                            </div>

                            <form action="checkout.php" method="POST">
                                <div class="mb-3">
                                    <label for="name" class="form-label fw-bold fs-3">Name</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="phone" class="form-label fw-bold fs-3">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                <div class="mb-3">
                                    <label for="address" class="form-label fw-bold fs-3">Address</label>
                                    <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                                </div>
                                <div class="total-price">Total: <?php echo number_format($grandTotal + 10000); ?> MMK</div>
                                <button type="submit" class="btn btn-success">Confirm Purchase</button>
                            </form>
                        <?php else: ?>
                            <p>Your cart is empty. <a href="product.php">Go shopping</a></p>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
    </section>

    <?php include_once('connect resource php/Footer.php'); ?> 
</body>
</html>
