<?php
// Start the session to store messages (optional, but useful for flash messages)
session_start();

// Include the database connection
include_once('connection.php');

// Initialize variables to store form data and errors
$firstName = $lastName = $username = $email = "";
$errors = [];

// Function to sanitize input data
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['signup'])) {
    // Sanitize and assign form inputs
    $firstName = sanitize_input($_POST["firstName"]);
    $lastName = sanitize_input($_POST["lastName"]);
    $username = sanitize_input($_POST["username"]);
    $email = sanitize_input($_POST["email"]);
    $password = $_POST["password"]; // Passwords are handled separately
    $confirmPassword = $_POST["confirmPassword"];
    $iAgree = isset($_POST['iAgree']) ? $_POST['iAgree'] : '';

    // Validate inputs
    if (empty($firstName)) {
        $errors[] = "First Name is required.";
    }

    if (empty($lastName)) {
        $errors[] = "Last Name is required.";
    }

    if (empty($username)) {
        $errors[] = "Username is required.";
    } elseif (strpos($username, '@') !== false) {
        $errors[] = "Username must not contain the '@' symbol.";
    }

    if (empty($email)) {
        $errors[] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    if (empty($confirmPassword)) {
        $errors[] = "Confirm Password is required.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($iAgree)) {
        $errors[] = "You must agree to the terms and conditions.";
    }

    // If no errors, proceed to register the user
    if (empty($errors)) {
        // Hash the password securely
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO users (firstName, lastName, username, email, password) VALUES (?, ?, ?, ?, ?)");

        if ($stmt) {
            // Bind parameters (s = string)
            $stmt->bind_param("sssss", $firstName, $lastName, $username, $email, $hashed_password);

            // Execute the statement
            if ($stmt->execute()) {
                // Registration successful
                // Optionally, set a success message in the session and redirect
                $_SESSION['success'] = "Registration successful! You can now log in.";
                header("Location: login.php");
                exit();
            } else {
                // Handle execution errors (e.g., duplicate username or email)
                if ($conn->errno == 1062) { // Duplicate entry error code
                    $errors[] = "Username or Email already exists.";
                } else {
                    $errors[] = "Error: " . $stmt->error;
                }
            }

            // Close the statement
            $stmt->close();
        } else {
            // Handle preparation errors
            $errors[] = "Error preparing the statement: " . $conn->error;
        }
    }

    // Close the database connection
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?>  
    <!-- Link -->
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/registrations/registration-9/assets/css/registration-9.css">
</head>
<body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    
    <!-- Registration -->
    <section class="py-2 py-md-3 py-xl-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="container py-2 py-md-3 py-xl-5 px-2 px-md-3 px-md-5" style="background-color: rgba(230, 230, 230, 0.835); border-radius:30px;">
                        <div class="row gy-4 align-items-center">
                            <div class="col-12 col-md-6 col-xl-5">
                                <div class="card border-0 rounded-4">
                                    <div class="card-body p-3 p-md-4 p-xl-5">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-4">
                                                    <h2 class="d-flex flex-column flex-md-row justify-content-center fs-1 pb-4" style="font-weight:bold;">Registration</h2>
                                                    <h3 class="d-flex flex-column flex-md-row justify-content-start pb-2 fs-6 fw-normal text-secondary">Enter your details to register</h3>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Display Errors -->
                                        <?php
                                        if (!empty($errors)) {
                                            echo '<div class="alert alert-danger"><ul>';
                                            foreach ($errors as $error) {
                                                echo '<li>' . htmlspecialchars($error) . '</li>';
                                            }
                                            echo '</ul></div>';
                                        }

                                        // Display success message if any (optional)
                                        if (isset($_SESSION['success'])) {
                                            echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
                                            unset($_SESSION['success']);
                                        }
                                        ?>

                                        <form method="post" action="">
                                            <div class="row gy-3 overflow-hidden">
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="text" class="form-control" name="firstName" id="firstName" placeholder="First Name" value="<?php echo htmlspecialchars($firstName); ?>" required>
                                                        <label for="firstName" class="form-label">First Name</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="text" class="form-control" name="lastName" id="lastName" placeholder="Last Name" value="<?php echo htmlspecialchars($lastName); ?>" required>
                                                        <label for="lastName" class="form-label">Last Name</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="text" class="form-control" name="username" id="username" placeholder="Username" pattern="^[^@]*$" title="Username must not contain the '@' symbol" value="<?php echo htmlspecialchars($username); ?>" required>
                                                        <label for="username" class="form-label">Username</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" value="<?php echo htmlspecialchars($email); ?>" required>
                                                        <label for="email" class="form-label">Email</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                                        <label for="password" class="form-label">Password</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" required>
                                                        <label for="confirmPassword" class="form-label">Confirm Password</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-check my-1">
                                                        <input class="form-check-input" type="checkbox" name="iAgree" id="iAgree" required>
                                                        <label class="form-check-label text-secondary" for="iAgree">
                                                            I agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="link-primary text-decoration-none fw-bold">terms and conditions</a>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="d-grid">
                                                        <button class="btn btn-brand btn-lg" type="submit" name="signup">Sign up</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                        
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-end mt-4">
                                                    <p class="m-0 text-secondary text-center">Already have an account? <a href="login.php" class="link-primary text-decoration-none fw-bold">Sign in</a></p>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-12">
                                                <p class="my-4 d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-center">Or continue with</p>
                                                <div class="d-flex gap-2 gap-sm-3 justify-content-center">
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-danger bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-google" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-primary bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-facebook" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-dark bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-apple" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-7">
                                <div class="d-flex justify-content-center" style="background-color: #105470; border-radius:30px;">
                                    <div class="col-12 col-xl-11 text-white">
                                        <img class="img-fluid rounded my-4" style="border-radius:30px; height: 900px;" loading="lazy" src="img/Signup.gif" alt="BootstrapBrain Logo">
                                        <hr class="border-white my-2 border-4">
                                        <h2 class="h1 my-2 ms-3">B&B Design Build Construction - Innovate, Design, Build</h2>
                                        <p class="lead my-2 ms-3">"At B&B Design Build, we transform your vision into reality with our expert construction services, combining innovative......</p>
                                        <div class="text-end me-3">
                                            <i class="bi bi-grip-horizontal" style="font-size: 48px; color: currentColor;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
</body>
</html>
