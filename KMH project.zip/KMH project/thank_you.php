<?php
session_start();
include('connection.php');

// Make sure the order details are set in the session after checkout
$order_number = $_SESSION['order_number'] ?? 'N/A'; // Replace with actual order number fetching logic
$total_amount = $_SESSION['total_amount'] ?? 0; // Replace with actual total amount fetching logic

// Optionally, clear the session variables if you don't want them to persist
// unset($_SESSION['order_number']);
// unset($_SESSION['total_amount']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Thank You</title>
    <?php include_once('connect resource php/head.php'); ?> 
    <link rel="stylesheet" href="css/custom menu.css">
</head>
<body>
    <?php include_once('connect resource php/Header Navbar.php'); ?>

    <section class="py-5 text-center">
        <div class="container">
            <h1>Thank You for Your Purchase!</h1>
            <p>Your order has been placed successfully.</p>
            <p>Your order number is: <strong>#<?php echo htmlspecialchars($order_number); ?></strong></p>
            <p>Total Amount: <strong><?php echo number_format($total_amount); ?> MMK</strong></p>
            <p>Estimated Delivery: <strong>1-2 weeks</strong></p>
            <a href="product.php" class="btn btn-primary">Continue Shopping</a>
        </div>
    </section>

    <?php include_once('connect resource php/Footer.php'); ?> 
</body>
</html>
