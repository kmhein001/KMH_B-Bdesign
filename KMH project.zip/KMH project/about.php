<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?>  
    <!-- Link -->
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/bsb-overlay/bsb-overlay.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/background/background.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/margin/margin.css">
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/utilities/padding/padding.css">
  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    <!-- About -->
    <section class="px-2 px-md-3 px-xl-5" style="background-color: rgb(255, 255, 255);">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="px-2 px-md-3 px-xl-5" style="background-color: rgba(211, 211, 211, 0.87);">
              <div class="container">
                <div class="row">
                  <div class="col-12">
                    <div class="p-2 p-md-3 p-xl-5" style="background-color:rgb(16, 84, 112);">
                      <div class="container">
                        <div class="row justify-content-md-center">
                          <div class="col-12 col-md-10">
                            <h3 class="my-6 display-5 text-center text-white fw-bold">About B&B Design Build: Building Dreams with Brick and Block</h3>
                            <p class="mb-5 text-white opacity-75 fs-4" style="text-align:justify;margin:20px;">At B&B Design Build, short for Brick and Block Design Build Construction, we bring together the art of traditional masonry with modern construction techniques. Our passion lies in crafting beautiful, functional spaces that stand the test of time. As a team of over 370 qualified experts, we are dedicated to delivering exceptional craftsmanship and innovative solutions that exceed our clients' expectations.</p>
                            <hr class="w-80 mx-auto mb-xl-9 border-white border-4">
                          </div>
                        </div>
                      </div>
                      <div class="container">
                        <div class="row gy-4 gy-lg-0 align-items-lg-center">
                          <div class="col-12 col-lg-6">
                            <img class="img-design1 rounded border border-dark" loading="lazy" src="img/About Home-1.jpg" width="450px" height="450px;" alt="About Us">
                          </div>
                          <div class="col-12 col-lg-6 col-xxl-6">
                            <div class="row justify-content-lg-end">
                              <div class="col-12 col-lg-11">
                                <div class="about-wrapper">
                                  <p class="lead mb-4 mb-md-5 text-white" style="text-align:justify;margin:20px;" >At B&B Design Build, our dedication to excellence extends beyond the construction of buildings to encompass a strong commitment to social responsibility. We believe that as a leader in the construction industry, we have a duty to positively impact the communities we serve and the world around us.</p>
                                  <div class="row gy-4 mb-4 mb-md-5">
                                    <div class="col-12 col-md-6">
                                      <div class="card border border-dark">
                                        <div class="card-body p-4">
                                          <h3 class="display-5 fw-bold text-center mb-2" style="color:brown">500+</h3>
                                          <p class="fw-bold text-center m-0">Successfully Completed Projects</p>
                                        </div>
                                      </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                      <div class="card border border-dark">
                                        <div class="card-body p-4">
                                          <h3 class="display-5 fw-bold text-center mb-2" style="color:brown">250+</h3>
                                          <p class="fw-bold text-center m-0">Innovative Designs Delivered .......</p>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <a href="Coming Soon About.php" class="btn btn-button-click bsb-btn-2xl" >Explore Our Story
                                     <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr class="w-100 mx-auto my-xl-9 border-white border-5">
                      <div class="container py-2 py-md-3 py-xl-5">
                        <div class="row justify-content-md-center">
                          <div class="col-12 col-md-10">
                            <h2 class="mb-4 display-5 text-white text-center">Our Best Offers</h2>
                            <p class="mb-5 text-white opacity-75 fs-4" style="text-align:justify;margin:20px;">We pride ourselves on delivering top-notch repair and maintenance solutions to cyclists of all levels.</p>
                            <hr class="w-80 mx-auto mb-xl-9 border-white border-4">
                          </div>
                        </div>
                      </div>
                      <div class="container">
                        <div class="row gy-4 gy-lg-0 align-items-lg-center">
                          <div class="col-12 col-lg-6">
                            <img class="img-fluid rounded border border-dark" loading="lazy" src="img/Construction Building.gif" alt="About Us">
                          </div>
                          <div class="col-12 col-lg-6 col-xxl-6">
                            <div class="row justify-content-lg-end justify-content-xxl-around">
                              <div class="col-12 col-lg-11 col-xxl-10">
                                <div class="card border-0 mb-4">
                                  <div class="card-body p-4">
                                    <h4 class="card-title mb-3">Our Expertise</h4>
                                    <ul class="list-unstyled m-0 p-0 d-sm-flex flex-sm-wrap">
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Custom Masonry</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Architectural Design</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Structural Enhancements</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Interior Finishing</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Landscaping and Hardscaping</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Foundation Work</span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <div class="card border-0 mb-4 mb-xxl-5">
                                  <div class="card-body p-4">
                                    <h4 class="card-title mb-3">Additional Services</h4>
                                    <ul class="list-unstyled m-0 p-0 d-sm-flex flex-sm-wrap">
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Custom Fixture Installation</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Lighting Solutions</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span>Exterior Enhancements</span>
                                      </li>
                                      <li class="py-1 d-flex align-items-center gap-2 col-sm-6">
                                        <span class="text-primary">
                                          <i class="bi bi bi-check-all" style="font-size: 24px; color: currentColor;"></i>
                                        </span>
                                        <span> Outdoor Living Spaces                                        </span>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                                <a href="Coming Soon About.php" class="btn btn-button-click bsb-btn-2xl" > Discover Our Journey
                                  <i class="bi bi-arrow-right-short" style="font-size: 20px; color: currentColor;"></i>
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <hr class="w-100 mx-auto my-xl-9 border-white border-5">
                      <div class="container">
                        <div class="row justify-content-md-center">
                          <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
                            <h2 class="mb-4 display-5 text-white text-center">Why Partner with Us</h2>
                            <p class="mb-5 text-white opacity-75 fs-4" style="text-align:justify;margin:20px;">At B&B Design Build, our unwavering dedication to quality and craftsmanship...</p>
                            <hr class="w-80 mx-auto mb-xl-9 border-white border-4">
                          </div>
                        </div>
                      </div>
                      <div class="container">
                        <div class="row gy-4 gy-lg-0 align-items-lg-center">
                          <div class="col-12 col-lg-6">
                            <img class="img-fluid rounded border border-dark" loading="lazy" src="img/About-Partner.gif" alt="About 6">
                          </div>
                          <div class="col-12 col-lg-6">
                            <div class="row justify-content-xl-end">
                              <div class="col-12 col-xl-11">
                                <div class="accordion accordion-flush" id="accordionAbout6">
                                  <div class="accordion-item mb-4 border border-dark">
                                    <h2 class="accordion-header" id="headingOne">
                                      <button class="accordion-button bg-transparent text-black fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        Competitive Pricing
                                      </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionAbout6">
                                      <div class="accordion-body">
                                        Our Competitive Pricing Promise ensures that you receive exceptional value for your investment... Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consectetur, laborum voluptas ipsum et vel nostrum libero voluptatem ea distinctio cumque. Molestias temporibus consequatur rerum harum recusandae eaque corporis iure esse.
                                      </div>
                                    </div>
                                  </div>
                                  <div class="accordion-item mb-4 border border-dark">
                                    <h2 class="accordion-header" id="headingTwo">
                                      <button class="accordion-button collapsed bg-transparent text-black  fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        Lifetime Structural Warranty
                                      </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionAbout6">
                                      <div class="accordion-body">
                                        Enjoy the ultimate peace of mind with our lifetime structural warranty... Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eveniet consequuntur hic velit consequatur praesentium illum, eos placeat! Iusto ullam similique expedita in nostrum, praesentium quos quibusdam. At illo vero inventore.
                                      </div>
                                    </div>
                                  </div>
                                  <div class="accordion-item mb-4 border border-dark">
                                    <h2 class="accordion-header" id="headingThree">
                                      <button class="accordion-button collapsed bg-transparent text-black fs-4 fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                        Premium Materials
                                      </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionAbout6">
                                      <div class="accordion-body">
                                        We use only the highest quality materials... Lorem, ipsum dolor sit amet consectetur adipisicing elit. Exercitationem officia placeat corrupti, distinctio vero amet autem, tempore nemo et id, nostrum reprehenderit sunt? Voluptatem mollitia vel dolorem ea distinctio. Debitis.
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
  </body>
</html>