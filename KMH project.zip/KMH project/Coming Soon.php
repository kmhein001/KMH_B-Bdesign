<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?>  
  </head>
  <body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    <!-- coming soon Page -->
    <section class="py-6 py-md-5 min-vh-100 d-flex justify-content-center align-items-center">
        <div class="container">
        <div class="row">
            <div class="col-12">
            <div class="text-center">
                <h2 class="d-flex justify-content-center align-items-center gap-2 mb-4">
                <img src="img/Coming soon.gif" width="500px" height="500px"  alt="coming soon">
                </h2>
                <h3 class="h2 mb-2">Oops! This page isn't available yet.</h3>
                <p class="mb-5">The page you are trying to access is currently under construction. Please check back later.</p>
                <a class="btn btn-brand bsb-btn-5xl rounded-pill px-5 fs-6 m-0" href="home.php" role="button">Return to Home</a>
            </div>
            </div>
        </div>
        </div>
    </section>
    <!-- Footer -->
    <?php include_once('connect resource php/Footer.php'); ?> 
  </body>
</html>