<?php
// Start session
session_start();

// Include the database connection
include_once('connection.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Head -->
    <?php include_once('connect resource php/head.php'); ?>
    <style>
        .card-img-top {
            height: 200px; /* Set uniform height */
            object-fit: cover; /* Ensures images maintain aspect ratio */
        }

        /* Additional custom styles */
        .list-group-item {
            transition: background-color 0.2s ease;
        }

        .list-group-item:hover {
            background-color: #f8f9fa; /* Light grey on hover */
        }
    </style>
</head>
<body>
    <!-- Header Navbar -->
    <?php include_once('connect resource php/Header Navbar.php'); ?>

    <!-- Product Section -->
    <section class="p-2 p-md-3 p-xl-5" style="background-color: rgb(255, 255, 255);">
        <div class="container-fluid">
            <div class="row align-items-center gy-3 gy-md-0 gx-xl-5">
                <div class="col-12">
                    <div class="container">
                        <div class="row">
                            <!-- Sidebar -->
                            <?php include_once('connect resource php/product sidebar.php'); ?>

                            <!-- Content -->
                            <div class="col-lg-9">
                                <header class="d-sm-flex align-items-center border-bottom mb-4 pb-3">
                                    <strong class="d-block py-2">
                                        <?php 
                                            // Pagination setup
                                            $limit = 6; // Number of products per page
                                            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page
                                            $offset = ($page - 1) * $limit; // Offset for SQL query

                                            // Fetch total number of products for pagination
                                            $totalQuery = "SELECT COUNT(*) as total FROM productlist";
                                            $totalResult = mysqli_query($conn, $totalQuery);
                                            $totalRow = mysqli_fetch_assoc($totalResult);
                                            $totalProducts = $totalRow['total']; // Total number of products
                                            $totalPages = ceil($totalProducts / $limit); // Total pages
                                            echo $totalProducts . " Items found"; 
                                        ?>
                                    </strong>
                                    <div class="ms-auto">
                                        <select class="form-select d-inline-block w-auto border pt-1">
                                            <option value="0">Best match</option>
                                            <option value="1">Recommended</option>
                                            <option value="2">High rated</option>
                                            <option value="3">Randomly</option>
                                        </select>
                                        <div class="btn-group shadow-0 border"> 
                                            <a href="?view=list" class="btn btn-light <?php echo (isset($_GET['view']) && $_GET['view'] === 'list') ? 'active' : ''; ?>" title="List view">
                                                <i class="bi bi-list fa-lg"></i>
                                            </a>
                                            <a href="?view=grid" class="btn btn-light <?php echo (isset($_GET['view']) && $_GET['view'] === 'grid') ? 'active' : ''; ?>" title="Grid view">
                                                <i class="bi bi-grid fa-lg"></i>
                                            </a>
                                        </div>
                                    </div>
                                </header>

                                <!-- Fetch and Display Products -->
                                <?php
                                // Fetch products from the database with LIMIT and OFFSET for pagination
                                $query = "SELECT id, name, subtitle, price, discount, description, img FROM productlist ORDER BY id ASC LIMIT ? OFFSET ?";
                                $stmt = mysqli_prepare($conn, $query);
                                mysqli_stmt_bind_param($stmt, 'ii', $limit, $offset);
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);

                                // Check for errors in the query execution
                                if (!$result) {
                                    echo "<p>Error fetching products: " . mysqli_error($conn) . "</p>";
                                } else {
                                    // Check if there are products
                                    if (mysqli_num_rows($result) > 0) {
                                        // Initialize view mode
                                        $viewMode = isset($_GET['view']) ? $_GET['view'] : 'grid'; // Default to grid view

                                        // Start the selected view mode
                                        if ($viewMode === 'list') {
                                            echo '<div class="list-group">'; // Start list group
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                $name = htmlspecialchars($row['name']);
                                                $subtitle = htmlspecialchars($row['subtitle']);
                                                $price = (float) htmlspecialchars($row['price']);
                                                $discount = (float) htmlspecialchars($row['discount']);
                                                $description = htmlspecialchars($row['description']);
                                                $image = htmlspecialchars($row['img']);
                                                $id = (int)$row['id'];

                                                // Calculate final price if discount exists
                                                $finalPrice = ($discount > 0) ? $price - $discount : $price;

                                                // Display each product in list format
                                                echo '<div class="list-group-item list-group-item-action border rounded-3">';
                                                echo '<div class="row">';
                                                echo '<div class="col-md-3">';
                                                echo '<img src="admin/img/addproduct/' . $image . '" class="img-fluid rounded-start" alt="' . $name . '">';
                                                echo '</div>';
                                                echo '<div class="col-md-9">';
                                                echo '<a href="Product Coming Soon.php" class="text-decoration-none text-success"><h3 class="card-text py-1">' . $name . '</h3></a>';
                                                echo '<p class="text-muted">' . $subtitle . '</p>';
                                                if ($discount > 0) {
                                                    echo '<p><strong class="text-danger"><del>' . number_format($price) . ' MMK</del></strong></p>';
                                                    echo '<p><strong>' . number_format($finalPrice) . ' MMK (Save: ' . number_format($discount) . ' MMK)</strong></p>';
                                                } else {
                                                    echo '<p><strong>' . number_format($price) . ' MMK</strong></p>';
                                                }
                                                echo '<p>' . $description . '</p>';
                                                echo '<div class="card-footer d-flex justify-content-center align-items-center mt-auto">';
                                                echo '<a href="add_to_cart.php?action=add&product_id=' . $id . '&product_name=' . urlencode($name) . '&price=' . $price . '" class="btn custom-icon-color-add icon-hover-add fs-5 mx-2"><i class="bi bi-plus-square-fill"></i></a>';
                                                echo '<a href="Product Coming Soon.php" class="btn custom-icon-color-fav icon-hover-fav mx-2"><i class="bi bi-suit-heart-fill text-secondary fs-5"></i></a>';
                                                echo '</div>'; // Close card-footer
                                                echo '</div>'; // Close col-md-9
                                                echo '</div>'; // Close row
                                                echo '</div>'; // Close list-group-item
                                            }
                                            echo '</div>'; // Close list group
                                        } else {
                                            // Default to grid view
                                            echo '<div class="row">'; // Start grid row
                                            while ($row = mysqli_fetch_assoc($result)) {
                                                $name = htmlspecialchars($row['name']);
                                                $subtitle = htmlspecialchars($row['subtitle']);
                                                $price = (float) htmlspecialchars($row['price']);
                                                $discount = (float) htmlspecialchars($row['discount']);
                                                $description = htmlspecialchars($row['description']);
                                                $image = htmlspecialchars($row['img']);
                                                $id = (int)$row['id'];

                                                // Calculate final price if discount exists
                                                $finalPrice = ($discount > 0) ? $price - $discount : $price;

                                                // Display each product in grid format
                                                echo '<div class="col-md-4 mb-4">'; // Column for product card
                                                echo '<div class="card shadow-sm border rounded-3">'; // Card wrapper
                                                echo '<img src="admin/img/addproduct/' . $image . '" class="card-img-top" alt="' . $name . '">';
                                                echo '<div class="card-body">';
                                                echo '<a href="Product Coming Soon.php" class="text-decoration-none text-success"><h3 class="card-text py-1">' . $name . '</h3></a>';
                                                echo '<p class="card-text text-muted">' . $subtitle . '</p>';
                                                if ($discount > 0) {
                                                    echo '<p><strong class="text-danger"><del>' . number_format($price) . ' MMK</del></strong></p>';
                                                    echo '<p><strong>' . number_format($finalPrice) . ' MMK (Save: ' . number_format($discount) . ' MMK)</strong></p>';
                                                } else {
                                                    echo '<p><strong>' . number_format($price) . ' MMK</strong></p>';
                                                }
                                                echo '<p class="card-text">' . $description . '</p>';
                                                echo '</div>'; // Close card-body
                                                echo '<div class="card-footer d-flex justify-content-center align-items-center mt-auto">';
                                                echo '<a href="add_to_cart.php?action=add&product_id=' . $id . '&product_name=' . urlencode($name) . '&price=' . $price . '" class="btn custom-icon-color-add icon-hover-add fs-5 mx-2"><i class="bi bi-plus-square-fill"></i></a>';
                                                echo '<a href="Product Coming Soon.php" class="btn custom-icon-color-fav icon-hover-fav mx-2"><i class="bi bi-suit-heart-fill text-secondary fs-5"></i></a>';
                                                echo '</div>'; // Close card-footer
                                                echo '</div>'; // Close card
                                                echo '</div>'; // Close col-md-4
                                            }
                                            echo '</div>'; // Close grid row
                                        }
                                    } else {
                                        echo '<p>No products found.</p>';
                                    }
                                }

                                // Display pagination links
                                echo '<nav aria-label="Page navigation example">';
                                echo '<ul class="pagination justify-content-center">';
                                for ($i = 1; $i <= $totalPages; $i++) {
                                    echo '<li class="page-item' . ($i == $page ? ' active' : '') . '">';
                                    echo '<a class="page-link" href="?page=' . $i . '&view=' . $viewMode . '">' . $i . '</a>';
                                    echo '</li>';
                                }
                                echo '</ul>';
                                echo '</nav>';
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include_once('connect resource php/footer.php'); ?>
    
    <!-- Scripts -->
    <?php include_once('connect resource php/scripts.php'); ?>
</body>
</html>
