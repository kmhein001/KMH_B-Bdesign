<?php
// Start session
session_start();

// Include the database connection
include_once('connection.php');

// Initialize variables
$email = "";
$errors = [];

// Function to sanitize input data
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and assign the email
    $email = sanitize_input($_POST["email"]);

    // Validate inputs
    if (empty($email)) {
        $errors[] = "Email is required.";
    }

    // If no validation errors, proceed to reset password
    if (empty($errors)) {
        // Prepare SQL statement to check if email exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        
        if ($stmt) {
            // Bind parameters (s = string)
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            // Check if user exists
            if ($stmt->num_rows > 0) {
                // Generate a unique reset token
                $token = bin2hex(random_bytes(16)); // Generate a 32-character token
                
                // Prepare SQL to insert the token into the password_reset_tokens table
                $insert_stmt = $conn->prepare("INSERT INTO password_reset_tokens (email, token, created_at, expires_at) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 HOUR))");

                if ($insert_stmt) {
                    // Bind parameters
                    $insert_stmt->bind_param("ss", $email, $token);

                    // Execute the query
                    if ($insert_stmt->execute()) {
                        // Example: Here, you can send the email to the user with the reset link containing the token
                        // mail($email, "Password Reset", "Click this link to reset your password: http://yourwebsite.com/reset_password.php?token=$token");

                        // Set success message
                        $_SESSION['success'] = "Password reset link has been sent to your email.";
                        header("Location: password_reset.php");
                        exit();
                    } else {
                        $errors[] = "Failed to insert reset token. Please try again later.";
                        error_log("Insert Token SQL Error: " . $insert_stmt->error);
                    }
                    $insert_stmt->close();
                } else {
                    $errors[] = "An error occurred. Please try again later.";
                    error_log("SQL Error: " . $conn->error);
                }
            } else {
                $errors[] = "No account found with that email address.";
            }
            $stmt->close();
        } else {
            $errors[] = "An error occurred. Please try again later.";
            error_log("Password Reset SQL Error: " . $conn->error);
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Password Reset</title>
    <?php include_once('connect resource php/head.php'); ?> 
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.4/components/registrations/registration-9/assets/css/registration-9.css">
</head>
<body>
    <?php include_once('connect resource php/Header Navbar.php'); ?>
    
    <section class="py-2 py-md-3 py-xl-5" style="background-color: white;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="container py-2 py-md-3 py-xl-5 px-2 px-md-3 px-md-5" style="background-color: rgba(230, 230, 230, 0.835); border-radius:30px;">
                        <div class="row gy-4 align-items-center">
                            <div class="col-12 col-md-6 col-xl-7">
                                <!-- Left side content -->
                                <div class="d-flex justify-content-center" style="background-color: #105470;border-radius:30px;">
                                    <div class="col-12 col-xl-11 text-white">
                                        <img class="img-fluid rounded my-4" style="border-radius:30px;" loading="lazy" src="img/PasswordReset.gif" alt="BootstrapBrain Logo">
                                        <hr class="border-white my-2 border-4">
                                        <h2 class="h1 my-2 ms-3">B&B Design Build Construction - Innovate, Design, Build</h2>
                                        <p class="lead my-2 ms-3">"At B&B Design Build, we transform your vision into reality with our expert construction services, combining innovative......</p>
                                        <div class="text-end me-3">
                                            <i class="bi bi-grip-horizontal" style="font-size: 48px; color: currentColor;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-6 col-xl-5">
                                <div class="card border-0 rounded-4">
                                    <div class="card-body p-3 p-md-4 p-xl-5">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="mb-4">
                                                    <h2 class="d-flex flex-column flex-md-row justify-content-center fs-2 pb-3"><b>Password Reset</b></h2>
                                                    <h3 class="d-flex flex-column flex-md-row justify-content-center pb-3 fs-6 fw-normal text-secondary">Provide the email address associated with your account to recover your password.</h3>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Display Error Messages -->
                                        <?php
                                        if (!empty($errors)) {
                                            echo '<div class="alert alert-danger"><ul>';
                                            foreach ($errors as $error) {
                                                echo '<li>' . htmlspecialchars($error) . '</li>';
                                            }
                                            echo '</ul></div>';
                                        }

                                        // Display success message if applicable
                                        if (isset($_SESSION['success'])) {
                                            echo '<div class="alert alert-success">' . htmlspecialchars($_SESSION['success']) . '</div>';
                                            unset($_SESSION['success']);
                                        }
                                        ?>        

                                        <form action="password_reset.php" method="post">
                                            <div class="row gy-3 overflow-hidden">
                                                <div class="col-12">
                                                    <div class="form-floating mb-3">
                                                        <input type="email" class="form-control" name="email" id="email" placeholder="name@example.com" required>
                                                        <label for="email" class="form-label">Email</label>
                                                    </div>
                                                </div>
                                                <div class="col-12">
                                                    <div class="d-grid">
                                                        <button class="btn btn-brand btn-lg" type="submit">Reset Password</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>

                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-end mt-4">
                                                    <a href="login.php" class="link-primary text-decoration-none fw-bold">Login</a>
                                                    <a href="registration.php" class="link-primary text-decoration-none fw-bold">Register</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-12">
                                                <p class="my-5 d-flex gap-2 gap-md-4 flex-column flex-md-row justify-content-md-center">Or continue with</p>
                                                <div class="d-flex gap-2 gap-sm-3 justify-content-center">
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-danger bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-google" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-primary bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-facebook" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#comingSoonModal" class="btn btn-outline-dark bsb-btn-circle bsb-btn-circle-2xl">
                                                        <i class="bi bi-apple" style="font-size: 24px; color: currentColor;"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include_once('connect resource php/Footer.php'); ?>
</body>
</html>
